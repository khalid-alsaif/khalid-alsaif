# Sleep Health and Lifestyle Analysis

An exploratory notebook studying relationships between sleep quality, sleep disorders, and lifestyle factors.

## Technologies

Python / Jupyter / data analysis

## Explore the project

Open the notebook in Jupyter and install its imported dependencies. The dataset is omitted pending confirmation of its source and redistribution terms; supply Sleep_health_and_lifestyle_dataset.csv locally.

## Files

- `Project_ISE291.ipynb`

## Project context

Academic project: ISE291. These are archival portfolio files; builds and hardware behavior have not been revalidated. Team projects retain contributor names where available; individual ownership of all components is not implied.

Reports are provided as extracted text. Original images, formatting, signatures, student IDs, duplicate archives, and large demo files are omitted.
