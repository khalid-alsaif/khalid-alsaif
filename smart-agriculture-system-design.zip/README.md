# Smart Agricultural Monitoring and Control System

Engineering planning documents for a smart agricultural monitoring and control system, covering the problem statement, project management plan, business case, and engineering design.

## Technologies

Engineering design / project planning / smart agriculture

## Explore the project

This is a design-document portfolio project. No implementation code was supplied. Read the Markdown documents in docs; images and signature fields from the original Word files are omitted.

## Files

- `docs/1- Problem Statement.md`
- `docs/2- PMP.md`
- `docs/3- Business_Case_Document.md`
- `docs/4- EDD.md`

## Project context

Academic project: COE384. These are archival portfolio files; builds and hardware behavior have not been revalidated. Team projects retain contributor names where available; individual ownership of all components is not implied.

Reports are provided as extracted text. Original images, formatting, signatures, student IDs, duplicate archives, and large demo files are omitted.
