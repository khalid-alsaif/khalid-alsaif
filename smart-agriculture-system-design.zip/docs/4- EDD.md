# 4- EDD

King Fahad University of Petroleum and Minerales 

COE384 

Engineering Design Document (EDD)



Project Name:

Smart Agricultural Monitoring and Control System

Group Number:

Team 6

Date:

11/05/2025

Release:

Draft/Final

Student 1 Name:

Khalid Alsaif

Signature:



Student 1 ID: 

[student ID removed]





Author 2 Name:

Saud Alsaleem

Signature:



Student 2 ID: 

[student ID removed]





Author 3 Name:

Mojtaba Alsaad

Signature:



Student 3 ID: 

[student ID removed]





Author 4 Name:

Kureym Alzarea

Signature:



Student 4 ID: 

[student ID removed]





Author 5 Name:

Ahmed Alghamdi

Signature:



Student 5 ID: 

[student ID removed]





Document Number:

T242-COE384-EDD-002

Revision History

Revision Date

Previous Revision Date

Summary of Changes

Changes Marked

10/05/2025

28/04/2025

From our understanding of all the peer reviewers, we expanded the software part with more details on the AI part. Also, we did some changes on the cloud part and added more sequence diagrams. 























Approvals

This document requires the following approvals.  A signed copy should be placed in the project files.

Name

Signature

Title

Date of Issue

Version

Dr. Akram Fadhl N. Ahmed





Professor at Computer 

Engineering in KFUPM

28/4/2025

001

Dr. Akram Fadhl N. Ahmed







Professor at Computer 

Engineering in KFUPM



11/05/2025

002















Distribution

This document has been distributed to:

Name

Title

Date of Issue

Version

Abdulaziz Ashy

COE student at KFUPM

28/4/2025

001

Moaz Abdelaziz

COE student at KFUPM

28/4/2025

001

Abdullah Al-Arafat

COE student at KFUPM

28/4/2025

001

Ziad Algamdi

COE student at KFUPM

28/4/2025

001

Thamer Alotaibi

COE student at KFUPM

28/4/2025

001

Dr. Akram Fadhl N. Ahmed

Professor at Computer 

Engineering in KFUPM

28/4/2025

002





Contents

1.Executive Summary of Project Charter5

2.Document Overview5

3.Abbreviations and Glossary6

4.References7

5.Standard and regulatory References8

6.Architecture9

6.1.Architecture Overview9

6.2.Hardware architecture overview10

6.2.1.ESP32-C6 Microcontroller11

6.2.2.Temperature and Humidity Sensor12

6.2.3.Solenoid Valve12

6.2.4.Water Pump13

6.2.5.Relay Module13

6.2.6.Camera Module14

6.2.7.Pressure Sensor15

6.2.8.Weight Sensor16

6.2.9.Weight Transmitter16

6.2.10.RS232 to UART converter17

6.3.Software architecture overview17

6.3.1 Cloud Communication Module18

6.3.2 Sensor Data Storage and Management19

6.3.3 Security Module19

6.3.4 Irrigation Monitoring and Control Dashboard20

6.3.4 AI-Based Plant Health Monitoring System26

6.3.5.1. Image Processing and Classification Module27

6.3.5.2. Decision Logic Controller29

6.4 Third Party Software31

6.4.2 TensorFlow Lite33

6.4.3 OpenCV33

6.4.4 Flask34

6.4.5 NumPy34

6.4.6 Eclipse Paho MQTT Client35

6.4.7 Eclipse Mosquitto (MQTT Broker)35

6.4.8 Firebase Cloud Messaging (FCM)36

6.4.9 OpenWeatherMap API36

6.4.10 ESP-IDF36

7.Requirement Management38

7.1Use Cases39

7.1.1. Use Case 1: View Crop Health and Irrigation Status39

7.1.2. Use Case 2: Send Manual Irrigation Command41

7.1.3. Use Case 3: Perform Automatic Irrigation Decision43

7.1.4. Use Case 4: Notify Farmer of Alerts46

7.1.5. Use Case 5: Handle Maintenance Fault48

7.1.6. Use Case 6: Approve New User and Assign Roles50

7.2 Requirements52

7.3 Dynamic behavior of architecture53

8.Security and Privacy Considerations54

9. Sustainability and Environmental Impact57

9.1 Resource Efficiency57

9.2 Life Cycle Considerations57

9.3 Scalability58

10. Testing and Validation Strategy60

10.1 Test Methodologies60

10.2 Automation61

10.3 Performance & Stress Testing61

10.4 User Acceptance Testing (UAT)62

10.5 Regulatory or Certification Testing63

11. Declaration of use of AI64























































Executive Summary of Project Charter

The smart agricultural monitoring and control system project focuses on developing an automated irrigation system that improves crop yield and reduces water usage through sensor monitoring and IoT integration. The design includes both hardware and software components that enable farmers to detect, monitor, and manage the farm without having to visit the farm regularly. The hardware implementation includes the ESP32-C6 microcontroller, sensors to determine crop status, and solenoid valves to control the irrigation. The microcontroller is considered to be the heart of the system, it’s connected to the Tuya smart sensor via ZigBee to read the temperature and humidity of the crops, and a camera via Wi-Fi to detect if the crops are healthy, sick, or dead. The microcontroller also controls irrigation through a relay module that is connected to solenoid valves that take water from the water supply via a water pump, while also reading the water supply’s weight to prevent water shortage and reading the pressure of the water pipes to determine if there is a leakage. These components were chosen based on their affordability, energy efficiency, and compatibility with the ESP32 microcontroller. The software part of the project is driven by the data that is sent from the microcontroller to the AWS cloud using Wi-Fi, allowing the CNN model AI to process the data and make decisions that will control the actuators accordingly by sending the processed results back to the microcontroller. The farm owner can also view the status of the farm through dashboard mobile apps, providing real-time information about the crop’s health and irrigation status while also enabling manual control if needed. The key engineering decisions focus on using low-power consumption devices to ensure a long-lasting operational life. Security is addressed by allowing data access only to authorized personnel through dashboard authentication. In conclusion, the proposed system addresses the issues with traditional farming methods such as excessive water consumption by leveraging wireless sensors, cloud computing, and AI to automate the irrigation process and monitor crop health in real-time. 





















Document Overview  

This document presents the design and architecture of the Smart Agricultural Monitoring and Control System (SAMCS). The system is built for outdoor farm environments, where it combines plant image classification and environmental sensing to manage irrigation automatically. The goal is to reduce water waste, minimize the need for human monitoring, and support decision-making through a user-friendly mobile dashboard. A simplified diagram of the system and its key interactions is shown in Figure 1.

The solution supports three main types of users. Farmers rely on the mobile app to check crop conditions and control irrigation as needed. Farm owners are responsible for managing user access and overseeing system usage. Maintenance workers receive alerts whenever there's a fault or abnormal reading, so they can take action quickly. The system is intended for farms in rural areas with LTE or Wi-Fi coverage and requires only basic training for users to operate.

Functionality Overview: The system collects temperature, humidity, and soil moisture data using ESP32-based sensors. It also captures images of the crops through onboard cameras. All this data is sent wirelessly to AWS, where a CNN-based AI model processes the images and classifies plant health. Based on this, the system either triggers irrigation automatically or allows users to do it manually through the app. The dashboard provides a zone-based layout that shows the current status, irrigation history, and alerts for stressed or dead plants.

Key Interfaces: Input data comes from the field through the sensors and camera modules. These devices connect wirelessly to the cloud using MQTT (TLS) and HTTPS protocols. On the backend, AWS EC2 handles AI processing, classifying images and generating irrigation decisions. Image files are stored in AWS S3, while sensor logs and irrigation records are saved in DynamoDB. Notifications are managed using Firebase. Outputs include irrigation commands sent to actuators and live status updates shown on the dashboard, with optional alert notifications.

Technical Assumptions: The system assumes reliable 4G/Wi-Fi connectivity and that users will access the app on smartphones. AWS services (such as EC2, S3, and DynamoDB) must already be set up and ready. The ESP32 nodes are expected to run on solar or battery power. For the AI part, pre-trained models provided by research collaborators or university sources are used. The design also assumes compliance with data privacy rules for agricultural IoT and follows secure transmission practices.

Design Approach: SAMCS follows a modular and Agile-inspired development model. Each part of the system—from hardware and communication to cloud logic and the user interface—is developed and tested separately. This makes it easier to improve or add features later. The architecture is also built to scale, with future plans to add weather API integration, solar energy tracking, and more advanced data analytics.

























Abbreviations and Glossary



ADC: Analog to Digital Converter

DAC: Digital to Analog Converter

AI: Artificial Intelligence

SPI: Serial Peripheral Interface

I2C: Inter-Integrated Circuit

EDD: Engineering Design Document

PMP: Project Management Plan

AWS: Amazon Web Services

API: Application Programming Interface

M&C: Monitor and Control

PWM: Pulse Width Modulation

SAMCS: Smart Agricultural Monitoring and Control System 

UART: Universal Asynchronous Receiver / Transmitter

GPIO: General Purpose Input / Output

CNN: Convolutional Neural Network

MQTT: Message Queuing Telemetry Transport

HTTP: Hypertext Transfer Protocol

NumPy: Numerical Python

OpenCV: Open-Source Computer Vision Library

RTSP: Real-Time Streaming Protocol

TensorFlow Lite: Lightweight AI inference framework

TCP: Transmission Control Protocol

VM: Virtual Machine



































References

#

Document Identifier

Document Title



ESP32-C6

https://www.espressif.com/en/products/socs/esp32-c6 



Tuya Zigbee Wireless Soil Moisture Meter Temperature Humidity Tester

https://www.amazon.com/Wireless-Moisture-Temperature-Humidity-Waterproof/dp/B0CKZ1ZBGJ 



Walfront Brass Electric Solenoid Valve

https://amzn.eu/d/8hZKjhE 



Brushless Submersible Water Pump DC 12V

https://amzn.eu/d/37TIVke 



1 Channel Relay Module

https://robu.in/product/1-channel-relay-module-10a-with-optocoupler-isolation-24v-supports-high-and-low-triger/ 



ACB Self-Aligning Mount

https://www.vishay-loadcells-intertechnology.com/pdf/tedea/weigh/ACBMount.pdf 



1203 Weight Transmitter

https://www.rinstrum.com/wp-content/uploads/2018/08/1203-700-200.pdf 



MAX232 DB9

http://icmasteronline.com/product/max232-db9-serial-port-connector/ 



water oil fuel gas air pressure transmitter

https://a.co/d/5SMPC6h 



TensorFlow Repository

https://github.com/tensorflow/tensorflow



OpenCV Repository

https://github.com/opencv/opencv



Flask Repository

https://github.com/pallets/flask



MQTT Client Repository

https://github.com/eclipse/paho.mqtt.python



NumPy Repository

https://github.com/numpy/numpy



LS VISION Camera Product Page

https://www.lsvisionsolar.com/product/4g-outdoor-camera/



ESP IDF

https://docs.espressif.com/projects/esp-idf/en/stable/esp32c6/get-started/index.html 



Standard and regulatory References

#

Identifier

Link to the standard/regulatory 



ISO/IEC 25010

https://iso25000.com/index.php/en/iso-25010 



ZigBee

https://zigbeealliance.org/wp-content/uploads/2019/11/docs-05-3474-21-0csg-zigbee-specification.pdf 



IEEE 802.11

https://www.ieee802.org/11/ 



IEEE 829

https://standards.ieee.org/ieee/829/3787/ 



ISO/IEC 27001 

https://www.iso.org/isoiec-27001-information-security.html



RS-232

https://www.analog.com/media/en/technical-documentation/product-selector-card/rs232%20quick%20guide.pdf 





















Architecture 

Architecture Overview 



The Smart Agricultural Monitoring and Control System (SAMCS) functions as an organized system with multiple layers to merge sensor data from edge devices with AI-based cloud processing, along with mobile application oversight for automatic irrigation systems that use plant health indicators and environmental data. The designed architecture provides dependability alongside modularity and scalability, which serve real-world agricultural sites, especially those situated in distant rural areas where supervision is limited.

1. Edge Sensing and Data Collection Layer:

The ESP32-C6 microcontrollers function as edge-level devices that cover different farm zones. The devices feature temperature sensors, humidity sensors, and soil moisture sensors for environmental monitoring purposes. Each zone contains LS VISION LS-MS1-4G camera modules that take high-resolution pictures of plant leaves. MQTT over TLS transfers sensor data to the cloud, and HTTPS handles image file uploads. The system uses solar power and rechargeable batteries to operate edge devices, providing extended outdoor functionality.

2. Cloud Communication and Storage Layer:

The system uses this layer to ensure safe data storage and transfer operations for incoming data from field sources. AWS hosts the cloud gateway through which sensor readings and image files are transmitted using MQTT and HTTPS protocols. Sensor log information is stored in DynamoDB, and plant image data is stored in AWS S3. This layer handles interactions between the AI engine, decision logic, and the mobile dashboard. The cloud services operate with optimized efficiency to manage concurrent device uploads and asynchronous image classification jobs.

3. AI Processing and Irrigation Decision Layer:

AI processing takes place on an AWS EC2 virtual machine. The system executes a CNN model (built in TensorFlow Lite), which performs plant image classification into three categories: Healthy, Stressed, and Dead. The Decision Logic Controller evaluates sensor readings alongside classification results to establish suitable irrigation responses. The system controller enables either automatic irrigation control or user interface notification for manual irrigation based on established rules. This implemented logic allows for water conservation through proper irrigation and prevents the waste of water on non-viable plant zones.

4. User Interface and Dashboard Layer:

Farmers, owners, and maintenance teams access the mobile dashboard through Flutter to perform their tasks. The system presents live crop health data and sensor information, along with irrigation history for designated zones, through its interface. Through the system, users can execute manual irrigation commands while monitoring system alerts that result from AI module operations. The system employs access control to manage user roles while maintaining all API communications through secure RESTful HTTPS protocols. System alerts, which users can manage in real time, are delivered through Firebase notifications regardless of their field location.

5. Security and Integration Layer:

The system operates securely through TLS encryption, which protects all device-to-service communications. OAuth 2.0 is implemented for authenticating mobile users and maintaining appropriate role divisions. Cloud authentication of ESP32 devices happens through token-based authentication methods. The system integrates multiple modules through a framework that prevents data breaches, protects privacy, and maintains the integrity of health analytics results.

Deployment Context:

Edge Devices: ESP32-C6 microcontrollers and LS VISION cameras deployed in outdoor farm zones.

Cloud Services: AWS EC2 (AI engine), S3 (image storage), DynamoDB (logs), MQTT broker, and API Gateway.

User Interface: Mobile dashboard (Flutter app) for farmers and owners.

Power Source: Solar-powered and battery-backed ESP32 nodes.

Connectivity: LTE/4G or Wi-Fi is required for field-cloud communication.

























































































































Hardware architecture overview



Our design for the Smart Agricultural Monitoring and Control System will be implemented in a 200m x 200m farming area divided into 10 x 10 squares that will be monitored to improve the crops quality and optimize irrigation. The ESP32-C6 microcontroller will be connected to the Tuya wireless sensor via ZigBee to receive data and send it to the cloud for processing using AI. Then, the microcontroller will receive control signals from the cloud to open/close the relay through the GPIO pins. The relay is connected to the power supply and the solenoid valve. After that, the solenoid valve, which is connected to the water pump, will allow the water to flow and irrigate the farming area. At the same time, the pressure sensor monitors the pressure at the valve to determine if there is a leak. The microcontroller is also connected to a camera that will take images regularly and send them to the microcontroller using WIFI protocols, then the ESP32-C6 will send the image to the cloud for the AI to process the image to determine the crop’s health. Additionally, the water tank’s weight will be monitored using the ACB-self aligning mount to read the weight of the tank and it will be transmitted using the 1203 weight transmitter using RS232, however, the ESP32 doesn’t support that protocol so we need to use the MAX232 to convert from RS232 to UART so that the microcontroller can read the data.





















































































































ESP32-C6 Microcontroller



Identification

ESP32-C6 is an ARM-based dual-core microcontroller with integrated Wi-Fi and ZigBee. It controls sensors, communicates with the cloud, and executes irrigation control logic.

Purpose

Serves as the central unit for sensing, communication, and actuator control.



Technical Characteristics

Xtensa LX6 dual-core processor (up to 160 MHz)

IEEE 802.11 b/g/n (2.4 GHz) up to 150 Mbps data rate

Bluetooth 5.0 with HCL and L2CAP support

512 KB of RAM and up to 1 MB of embedded flash

AES-XTS, SHA-256, and RSA-4096 cryptographic accelerators

SPI, I2C, UART, I2S, PWM, ADC, DAC, and GPIO

2.0V to 3.6V operating voltage with external power supply up to 5.5V

ESP-IDF and SDK for application development

Interface

Wi-Fi: Sends data to cloud

ZigBee: Receives sensor data

GPIO: Controls relay

ADC: Reads pressure sensor

UART: Reads weight data (via MAX232)











Temperature and Humidity Sensor



Identification

A ZigBee-enabled soil sensor that measures soil moisture, temperature, and humidity in the farming environment.



Purpose

Monitors soil and air conditions, which influence plant stress and irrigation needs.

Technical Characteristics

Humidity range: 0–100% RH

Humidity accuracy: ±3% (0–50%), ±5% (50–100%)

Temperature range: -20°C to 60°C

Accuracy: ±1°C

Communication: ZigBee











Interface

ZigBee: Wireless data transmission to ESP32





Solenoid Valve



Identification

Walfront Brass Electronic Solenoid Valve is an electronically controlled valve that regulates water flow to the irrigation zones.

Purpose

Opens or closes the water flow based on the relay signal from the ESP32.



Technical characteristics

Voltage: 12V DC

Current: 300 mA

Operating fluid temperature: 0–55°C

Pressure: 0.02–0.8 MPa 









Interface

ADC ( to convert analog reading to digital)



Water Pump



Identification

A brushless DC submersible water pump that is used for drawing water from the tank.



Purpose

Pushes water through the valve system to irrigate active farm zones.



Technical characteristics

Voltage: 12V DC

Flow rate: 800 L/h (±10%)

Current: 920 mA

Noise: 35 dB

Cable length: 50 cm











Interface

Connected to power supply; controlled indirectly by relay





Relay Module



Identification

A single-channel relay module used to switch the solenoid valve and pump.



Purpose

Acts as a digital switch that controls irrigation devices upon receiving GPIO signals from the ESP32.



Technical characteristics

Rated current: 10A

Control voltage: 24V DC

Isolation: Optocoupler included





Interface

GPIO: Trigger signal from ESP32

Power: Drives solenoid and pump





Camera Module

Device Image



Identification

Name: LS VISION LS-MS1-4G Outdoor Camera

Manufacturer: LS VISION

Type: 4G Outdoor Smart AI Camera for Agriculture Monitoring

Purpose

The camera is used in the field to visually monitor plant health. It captures real-time images of plants and sends them to the cloud for AI processing. Based on the analysis:

If a plant is detected dead, the system avoids sending water to prevent waste.

If a plant is stressed (e.g., from heat), the system increases irrigation to support recovery.

This decision-making enhances water efficiency and prevents loss of healthy crops.

Software Component it Interfaces With

The camera streams images to the cloud via 4G.

These images are analyzed by a CNN-based AI model hosted on the cloud server.

The AI results are sent back to the irrigation control system via API.

Technical Characteristics

Resolution: 1080P HD (1920x1080)

Lens: 3.6mm, 2MP sensor

Connectivity: 4G LTE, Wi-Fi, Ethernet

AI Features: Supports object detection and image classification

Night Vision: IR-cut with up to 20 meters visibility

Power Supply: 12V DC / PoE optional

AI features: Edge object detection



Operating Conditions: -20°C to 60°C, IP66 waterproof rating

Interfaces

Communication: 4G LTE (via SIM), Wi-Fi, or Ethernet

Protocol: HTTP/HTTPS for cloud API upload

Format: RTSP/ONVIF for video stream (if needed for live access)





























Pressure Sensor



Identification

Industrial-grade pressure transmitter for detecting flow anomalies in irrigation lines

.

Purpose

Measures pipe pressure to detect leaks or blockages during irrigation.



Technical characteristics

Range: 0–600 Bar

Output: 4–20 mA analog signal

Accuracy: ±1%

Voltage: 12–24V DC

Temp range: -40°C to 105













Interface

ADC: Analog signal read by ESP32







Weight Sensor



Identification

ACB Self-Aligning Load Cell, used for high-accuracy tank weight measurement.



Purpose

Estimates water level in the tank to detect when refilling is needed.



Technical Characteristics

Capacities: 250-200 Kg

Hardened components at all bearing surfaces

Mechanical protection of the critical load introduction area

Built in horizontal movement control and lift off protection

Interface

Connects to 1203 transmitter (analog-to-digital conversion)



Weight Transmitter



Identification

1203 industrial transmitter that converts load cell data into RS232 format.



Purpose

Enables ESP32 to receive digital tank weight data.



Technical Characteristics

2 isolated analog outputs

Configurable output resolution

Power: 12–24V DC

Interface: RS232











Interface

RS232 output to MAX232 converter.





RS232 to UART converter



Identification

MAX232 DB9, a voltage-level converter from RS232 to TTL UART.



Purpose

Allows ESP32 to read data from RS232-only devices such as the 1203 transmitter.



Technical Characteristics

System power supply: from 3.0V to 5.5V

Interface output: UART

RS232 connector – DB9 socket

Interface

RS232 (input) to UART (output, connected to ESP32)









Software architecture overview











The software architecture of the Smart Agricultural Monitoring and Control System integrates multiple cloud-based and edge components to ensure efficient, scalable, and intelligent irrigation. It is divided into four main software layers: edge logic, cloud communication and storage, AI-based decision-making, and a mobile dashboard. Environmental data, along with plant images, soil moisture readings, temperature, and humidity measurements, are transmitted to the cloud through MQTT and HTTPS protocols at the edge level. The system's backend logic receives all inputs that are uploaded to AWS services. AWS IoT Core, together with API Gateway, functions as the secure data ingestion system within the cloud layer. The AWS S3 platform stores plant images, and DynamoDB serves as the database for sensor and irrigation logs. A TensorFlow Lite CNN model operating on AWS EC2 virtual machines analyzes plant health by classifying it into Healthy, Stressed, or Dead categories. The classification outcomes from sensor readings are processed by a rule-based system, which generates appropriate irrigation commands such as Normal, Extra, or No Water. The system uses MQTT commands to transmit decisions back to the field, where they appear in real-time within the farmer's mobile application. The Flutter-developed dashboard includes three main sections, which display plant health status and water levels, and irrigation history. Through the system, farmers possess the ability to issue manual commands to specific irrigation zones. The system protects user access through OAuth 2.0 authentication with Google/Apple login and uses Firebase Notifications to send alerts. The system uses OpenWeatherMap for climate data and Firebase for notifications to enable smart decision-making and user interaction.

6.3.1 Cloud Communication Module

Identification: MQTT and HTTPS Cloud Communication Gateway

Purpose: Acts as the middleware between ESP32 microcontrollers and the cloud AI infrastructure. This module manages all incoming and outgoing data streams, including image uploads, sensor data, and irrigation control commands.

Interfaces:

Input: MQTT messages from ESP32 devices, image files via HTTP POST

Output: Forward data to storage/database and trigger AI model invocation. Send back control signals to ESP32

Network Interfaces:

MQTT protocol over TLS (port 8883)

HTTP/HTTPS REST APIs over TLS

Resources:

Hosted on AWS IoT Core and API Gateway

Supports real-time messaging and cloud-triggered function execution

Stores image and sensor payloads in AWS S3 or DynamoDB

Integration Frameworks: AWS IoT Core, AWS Lambda triggers, MQTT brokers



6.3.2 Sensor Data Storage and Management

Identification: AWS Cloud-Based Data Storage System

Purpose: This module is responsible for persistently storing all sensor data, irrigation logs, plant health classifications, and image metadata. It enables historical tracking, performance analytics, and AI model retraining using archived datasets.

Interfaces:

Input: Data received from the cloud communication module and AI classification results

Output: Data consumed by dashboard, decision logic engine, or AI training pipeline

Network Interfaces:

HTTPS via AWS API Gateway for RESTful data retrieval

Internal communication with AWS Lambda and S3 over TCP/IP

Resources:

AWS DynamoDB: For structured sensor data and control logs

AWS S3: For storing raw and preprocessed plant images

AWS IAM and encryption services: For access control and security



6.3.3 Security Module

Identification: Cloud and Edge Device Security Layer

Purpose: Ensures secure user authentication, device access control, and encrypted data transmission between ESP32, cloud, and dashboard.

Interfaces:

Input: User login credentials, OAuth token requests, device identity headers

Output: Access tokens, secure cloud sessions, and denial messages for unauthorized access

Network Interfaces:

HTTPS (TLS 1.2+) for all user-side API communication

MQTT TLS encryption for device-to-cloud communication

Resources:

AWS IAM policies, OAuth 2.0 flows (Google/Apple), AES-256 TLS encryption

Role hierarchy: Owner, Approved User, Read-only Viewer

Enforced token expiration, and audit trails for sensitive API calls



6.3.4 Irrigation Monitoring and Control Dashboard

The following figures illustrate the main interface of the Irrigation M&C dashboard that farmers use to manage and monitor the smart irrigation system. The dashboard is implemented as a mobile app using Flutter and supports secure cloud integration. Users can register, track field performance, review environmental data, and manually control zone operations. Screenshots below represent each functional tab in the app along with its role in the overall software architecture.





The Irrigation M&C app gives the choice to create an account either by email, or continue with Google or Apple accounts





When the system is first implemented, the first account will be automatically the owner. After that, all other accounts must have, for security purposes, permission from the owner to enter the app.







Once entering the app, one will face the ‘info’ tab. In this tab, various information will be displayed. Such as the available amount of water supply, and if the water supply is nearly empty, it will show a message to remind the user to fill the tank of water. Moreover, this tab displays the outside temperature for easy reference with the temperature readings of the farming zones. Furthermore, it shows a line graph of the water consumed in the farm. It displays the number of liters of water in a specific month. It also shows a histogram of the maintenance logs. It shows how many times a farming zone has been under maintenance in a quarter.





In the ‘Overview’ tab, the user views his segmented farming area. It shows every farming zone and gives the temperature and soil moisture of it was acquired from the sensors in the field. Furthermore, it also reveals which zones are operating, to keep an eye on any potential defects in devices that might render a zone nonoperational. Moreover, in this tab, it gives the total number of operational zones out of all available zones. If all zones were working, a green circle would be shown in the ‘Operational Zones’ frame. If one or more zones are not operational, an orange circle will be shown. Finally, if all zones are nonoperational, a red circle will be shown.





The ‘Command’ tab enables the user to turn on/off farming zones. When a zone is shut off, all devices in the zone will be turned off, and vice versa. Furthermore, for easy tracking, a frame will be shown displaying the total number of zones that are turned off, called ‘Zone Status’. If the circle in the Zone Status is green, it indicates that no zones are off (i.e., all are working). Moreover, if the circle is orange, it means that one or more zones are turned off. Finally, a red circle indicates that all zones are turned off.





For future expansion, a financial page where one can organize one's farm’s business is planned. Thus, it has not been developed yet.



6.3.4 AI-Based Plant Health Monitoring System



The AI-Based Plant Health Monitoring System operates as a cloud-based intelligent software component that performs automated crop health evaluation to trigger suitable irrigation decisions. The system serves as the main intelligence unit that analyzes visual and environmental data to optimize irrigation control through real-time feedback from cameras and sensors. The software component links with LS VISION LS-MS1-4G cameras and sensor-equipped microcontrollers to perform plant health classification and generate appropriate irrigation commands. The system consists of two interconnected modules: the Image Processing and Classification Module and the Decision Logic Controller. These two modules share a cloud environment through TCP/IP interfaces, enabling scalability, efficient processing, and communication with the microcontroller interface and cloud dashboard.

The virtual machine hosting the AI component requires at least 2 vCPUs and 2 GB of RAM to execute lightweight AI inference models using TensorFlow Lite. The system operates without GPU acceleration because its models are designed for fast cloud-based inference. It uses MQTT or HTTPS protocols to communicate with microcontrollers while sending status updates to the irrigation management dashboard, which is maintained independently by another team member.





6.3.5.1. Image Processing and Classification Module

Identification: Image Classifier and Preprocessor for Crop Health

Purpose: This module is responsible for analyzing raw images captured by the LS VISION LS-MS1-4G cameras installed across the farming zones. Its core task is to classify the health condition of each observed plant into three categories: Healthy, Stressed, or Dead. It uses a convolutional neural network (CNN) model deployed with TensorFlow Lite to perform inference in real-time. The model is trained to recognize visual symptoms of dehydration, disease, or growth anomalies. Based on classification outcomes, the data is forwarded to the Decision Logic Controller to make actuation decisions.

Interfaces:

Input: Images from the LS-MS1-4G camera sent via cloud upload

Output: JSON-formatted classification result (e.g., {"zone": "3", "status": "Stressed"})

Network Interfaces:

Communicates using TCP/IP protocols over Wi-Fi or 4G to receive image data from the camera.

Resources:

Cloud VM: 2-core CPU, 2 GB RAM,

Frameworks: TensorFlow Lite, OpenCV, NumPy

Image Format: 224x224 RGB normalized tensor

Processing Time: ~200 ms per image

Description and Functional Flow: When a new image is received from a camera, the module performs preprocessing using OpenCV (resizing, normalization), then feeds the result to the ML model for prediction. The output probabilities are interpreted and converted to a health label. This output is packaged into a structured format and sent to the decision controller.

Code Output: 



The image above shows the AI model's evaluation results after training it to detect plant health status from images. The final test accuracy reached 92.30%, meaning the model correctly predicted plant health in over 92% of test cases. The classification report includes three key metrics for each class (Dead, Healthy, and Stressed):

Precision shows how many predicted labels were actually correct.

Recall reflects how well the model identified all real cases of each class.

F1-score balances both precision and recall for overall reliability.

For example, the model identified healthy plants with 92% precision and 97% recall, resulting in a strong F1-score of 0.94. Similarly, it classified stressed plants with 96% precision and 94% F1-score. The confusion matrix confirms that the model correctly identified most cases across all three classes, with very few misclassifications. These results prove the AI model is highly effective and reliable for smart plant health monitoring in real-world farms.



6.3.5.2. Decision Logic Controller

Identification: Irrigation Decision Engine

Purpose: The Decision Logic Controller is responsible for generating intelligent irrigation commands based on AI-classified plant health statuses and environmental sensor data (such as soil moisture and temperature). Its primary role is to conserve water and improve plant health by adjusting irrigation on a zone-by-zone basis. It operates as a microservice on the same cloud instance as the classifier and applies rule-based logic to translate sensor input and image classification into actuator commands.

Interfaces:

Input: Health status labels from the classifier module, environmental readings from sensors 

Output: Actuator control commands (e.g., zone ON/OFF, increase flow)

Network Interfaces:

Publishes decisions using MQTT protocol via TCP/IP to the ESP32.

Resources:

Runtime: Python-based cloud logic

Libraries: Flask, Paho MQTT 

Description and Functional Flow: This module first receives the plant health status per zone. It then matches this data with corresponding soil moisture and temperature values obtained from the microcontroller. A rule-based function is used to determine whether to irrigate a zone, increase water flow, or stop irrigation altogether. The controller sends this decision to the microcontroller through a lightweight messaging protocol, triggering actuators for precise control.

Interpretation Logic Overview: The decision logic interprets the AI classification results as follows:

If Dead → send "No water" command

If Stressed → send "Extra water" command

If Healthy → send "Normal water" command

This rule-based strategy ensures water efficiency while maintaining crop health.

Pseudocode for a part of Implementation:

Code Output:



This picture shows the final result from the second AI model in our system. It predicts the irrigation decision (Extra Water, No Water, Normal Water) based on both the plant health from the first AI part and the sensor data like soil moisture, temperature, and humidity. The final accuracy is 99.69%, which means the model was almost perfect in its predictions. The classification report shows that the model did really well in all three classes, with very high precision and recall. The confusion matrix at the bottom confirms this, as most predictions were correct with very few mistakes. This shows our AI model is strong and can be trusted to help make smart irrigation choices.







6.4 Third Party Software

















































































































































































































































































 6.4.1 Cloud Backend (AWS)

The cloud backend of the Smart Agricultural Monitoring and Control System serves as the central hub for data collection, processing, storage, and decision-making. The system is built upon Amazon Web Services (AWS) to guarantee scalability, high availability, and secure integration with IoT devices and third-party services. This backend handles MQTT and HTTPS data from edge sensors and cameras, stores image and sensor logs in cloud storage, and runs the AI models on virtual machines. It also supports remote updates, alert systems, and mobile dashboard access for farmers.

6.4.1.1 AWS Overview:



AWS API Gateway:

Purpose: Receives incoming HTTPS requests (sensor/image uploads), provides secure access to third-party APIs (e.g., OpenWeatherMap), and directs calls to appropriate backend Lambda functions.

Security: Acts as a proxy to protect internal services and hides API keys from exposure.

Used For: Image uploads, login requests, and command syncs between cloud and mobile app.



AWS Lambda Functions:

Purpose: Serverless compute layer triggered by cloud events (image arrival, AI request).

Functions Include:

POST /imageUpload: Triggers image preprocessing and classification.

POST /sensorData: Logs time-series sensor readings.

POST /decision: Stores AI irrigation output.

Benefits: Cheaper and scalable over EC2 for event-based logic.\



Amazon S3 (Simple Storage Service):

Purpose: Stores raw and preprocessed plant images and optionally AI model binaries.

Access: Private buckets with IAM role-based permissions.

Usage: Receives images from ESP32-CAM or edge camera via HTTPS.



DynamoDB:

Purpose: Stores structured data such as:

Sensor readings (moisture, temperature, humidity)

AI classification results

Irrigation command logs per zone

Advantage: NoSQL flexibility and scalability.



AWS IoT Core:

Purpose: Manages secure MQTT communication with ESP32 devices.

Supports:

Device identity

MQTT-based decision dispatching

Rule engine for triggering functions on incoming messages



AWS CloudWatch:

Purpose: Monitoring, error tracking, and Lambda performance logs.

Usage: Detects AI failures, sends alerts, and supports debugging.



AWS CodePipeline & CodeBuild (Optional for CI/CD):

Purpose: Automates testing and deployment of Lambda code, S3 configurations, and dashboard builds.

Usage: Auto-pushes updated AI models or dashboard content.



 AWS Cognito (or Firebase Auth Integration):

Purpose: Supports OAuth 2.0 user login (Google, Apple).

Usage: Authenticates dashboard users and manages session tokens.



6.4.2 TensorFlow Lite

Identification and Version: TensorFlow Lite v2.10

Purpose: Performs real-time classification of plant images into Healthy, Stressed, or Dead categories using a pre-trained CNN model hosted on an EC2 VM.

Vendor or Source: Open source via GitHub (https://github.com/tensorflow/tensorflow)

Maintenance/Update Cycle: Monthly minor updates, major versions every 6 months.

Hardware/Software Dependencies: Requires Python 3.7+, NumPy, and a Linux-based cloud server (AWS EC2 VM).

Interfaces and Data Flows:

Receives 224×224 RGB image tensors from OpenCV.

Outputs classification in JSON to the Irrigation Decision Engine.



6.4.3 OpenCV

Identification and Version: OpenCV v4.8.0 (opencv-python)

Purpose: Preprocesses captured plant images by resizing, normalizing, and converting them into tensors for AI model input.

Vendor or Source: OpenCV.org (https://opencv.org/)

Maintenance/Update Cycle: Every 3–4 months by the OpenCV developer community.

Hardware/Software Dependencies: Requires NumPy, Python 3.7+, and compatible with Linux (Ubuntu VM).

Interfaces and Data Flows:

Receives raw image input from the edge device.

Sends preprocessed tensors to TensorFlow Lite for classification.



6.4.4 Flask

Identification and Version: Flask v2.3.2

Purpose: Lightweight Python web framework used to expose irrigation API endpoints and connect the AI inference logic to cloud messaging.

Vendor or Source: Open-source via GitHub (GitHub - pallets/flask: The Python micro framework for building web applications.)

Maintenance/Update Cycle: Regular updates every few months.

Hardware/Software Dependencies: Requires Python 3.7+, runs on Ubuntu VM or AWS Lambda container.

Interfaces and Data Flows:

Exposes /predict, /decision, and /status endpoints.

Interfaces with the MQTT client and mobile dashboard backend.



6.4.5 NumPy

Identification and Version: NumPy v1.23.0

Purpose: Handles numerical tensor operations during image preprocessing and classification output formatting.

Vendor or Source: NumPy Developers – Open-source via GitHub (https://github.com/numpy/numpy)

Maintenance/Update Cycle: Monthly patch releases; major versions every 6 months.

Hardware/Software Dependencies: Python 3.7+, required by OpenCV and TensorFlow.

Interfaces and Data Flows:

Used internally within the AI processing module.

Provides matrix manipulation functions and image tensor formatting.



6.4.6 Eclipse Paho MQTT Client

Identification and Version: Eclipse Paho MQTT Client v1.6.1 (Python)

Purpose: Enables cloud backend to publish control commands to ESP32 clients and subscribe to sensor updates.

Vendor or Source: Eclipse Foundation – https://www.eclipse.org/paho/

Maintenance/Update Cycle: Minor updates 2–3 times per year.

Hardware/Software Dependencies: Python 3.x, works with Mosquitto or AWS IoT Core.

Interfaces and Data Flows:

Publishes irrigation decisions to topic zone/control.

Subscribes to sensor/data for temperature, soil moisture, and humidity readings.



6.4.7 Eclipse Mosquitto (MQTT Broker)

Identification and Version: Mosquitto v2.0

Purpose: Lightweight publish/subscribe MQTT broker used for real-time communication between ESP32 edge devices and the cloud server.

Vendor or Source: Eclipse Foundation (https://mosquitto.org/)

Maintenance/Update Cycle: Monthly patches; community maintained.

Hardware/Software Dependencies: Linux OS, port 1883/8883 open; used in Ubuntu server backend.

Interfaces and Data Flows:

Receives device telemetry and routes it to cloud modules.

Sends irrigation decisions from Flask API to field actuators.



6.4.8 Firebase Cloud Messaging (FCM)

Identification and Version: Firebase Cloud Messaging SDK (2025)

Purpose: Sends notifications to the farmer’s mobile app (Flutter) about irrigation status, errors, or tank level alerts.

Vendor or Source: Google Firebase (https://firebase.google.com/)

Maintenance/Update Cycle: Cloud-hosted; updated by Google frequently.

Hardware/Software Dependencies: Requires Firebase mobile SDK, Android/iOS mobile environment.

Interfaces and Data Flows:

Triggered via HTTP call from backend upon irrigation event.

Pushes notifications to subscribed mobile clients.



6.4.9 OpenWeatherMap API

Identification and Version: OpenWeatherMap API v3.0

Purpose: Fetches real-time weather data (temperature, rain, humidity) to support irrigation logic.

Vendor or Source: OpenWeather Ltd. (https://openweathermap.org/)

Maintenance/Update Cycle: Live updates every 10 minutes; managed by vendor.

Hardware/Software Dependencies: Requires HTTPS endpoint and API key; compatible with Python requests.

Interfaces and Data Flows:

Backend fetches weather forecast before each irrigation cycle.

Data is used to cancel or modify irrigation commands if rain is predicted.

6.4.10 ESP-IDF

Identification and version: ESP-IDF v5.4.1 (Espressif IoT Development Framework) 

Purpose: development framework for ESP32, ESP32-S, and ESP32-C series microcontrollers that provide APIs for Wi-Fi, Bluetooth, FreeRTOS, and peripheral control (GPIO, I2C, SPI, etc.)

Vendor or source: Espressif Systems (https://www.espressif.com/)

Maintenance/update cycle: monthly bug fixes and major updates every 6-12 months

Hardware/software dependencies: 

OS: windows/macOS/Linux

Toolchain: Xtensa-ESP32 or RISC-V GCC compiler

Python v3.7 + for building scripts

Interfaces and data flow:

APIs and protocols:

Wi-Fi: IEEE 802.11 b/g/n

Bluetooth: BLE 5.0 +

Peripherals: I2C, SPI, UART, ADC, PWM

Cloud Integration:

MQTT for AWS IoT

HTTP/REST to communicate with custom APIs

Debugging:

JTAG for hardware debugging

Logging for Serial/UART output or Wi-Fi logs























Class Diagram for Software architecture: 













































































































































































































































































































Requirement Management



Use Cases

7.1.1. Use Case 1: View Crop Health and Irrigation Status

Actor(s): Farmer, Cloud System (AWS)Preconditions:

The farmer is logged into the mobile dashboard.

Health and sensor data already processed by cloud system.

Main Flow:

Farmer opens the mobile app and selects the overview tab.

The system sends a request to the cloud for health and irrigation data.

The cloud returns JSON data with crop status and logs.

The system displays plant health, sensor readings, and irrigation logs in a zone-based grid.

Alternate Flows:

If cloud is unavailable, display cached data or show an error.

If no internet, show “offline” state message.

Postconditions:

Farmer sees the latest health and water information.





Activity Diagram:







7.1.2. Use Case 2: Send Manual Irrigation Command

Actor(s): Farmer, Cloud System (AWS)Preconditions:

The dashboard app is open, and the farmer has permission to issue commands.

Main Flow:

Farmer opens the command tab.

The app displays the current irrigation status per zone.

The farmer selects a zone and issues a command.

The system sends a command via MQTT to the cloud.

The cloud returns a confirmation (acknowledgment).

The app updates the status display.

Alternate Flows:

If MQTT fails, show error and retry.

If there is no internet, notify that the command was not sent.

Postconditions:

Command is applied and displayed on the interface.





Activity Diagram:



7.1.3. Use Case 3: Perform Automatic Irrigation Decision

Actor(s): Cloud System (AWS), Weather APIPreconditions:

Sensor and image data are available on cloud.

AI model is deployed and running.

Main Flow:

Cloud receives image and sensor data.

It triggers the AI model (TFLite) to classify plant health.

It queries the weather forecast (external API).

Combines AI result + sensor + weather to compute irrigation.

Sends command to field via MQTT.

Logs the command and stores results.

Alternate Flows:

If AI fails, use fallback logic.

If weather data are unavailable, assume dry.

If MQTT fails, retry.

Postconditions:

Irrigation is autonomously optimized and recorded.





























Activity Diagram:





7.1.4. Use Case 4: Notify Farmer of Alerts

Actor(s): Cloud System (AWS), Firebase Notification Service, FarmerPreconditions:

An alert condition (e.g., low water, sensor fault) exists.

Main Flow:

Cloud detects issues and formats an alert.

Sends alert to Firebase Cloud Messaging (FCM).

Notification appears on the farmer’s device.

App stores alert in log and shows it in the Notification Tab.

Alternate Flows:

If the user is offline, retry later.

If FCM fails, register the token again on the next session.

Postconditions:

Alerts are received or queued until online.











Activity Diagram:













7.1.5. Use Case 5: Handle Maintenance Fault

Actor(s): Cloud System (AWS), Farmer, Maintenance WorkerPreconditions:

The system detects a fault, or farmers manually report an issue.

Main Flow:

Cloud detects failure or the farmer reports it.

Alert sent to the farmer and maintenance worker.

The worker opens the maintenance tab and views the fault.

The worker performs a fix.

Worker updates fix status and notes.

Cloud closes the alert and logs the fix.

Alternate Flows:

If the issue is unresolved, the system prompts rechecking.

If offline, sync later.

Postconditions:

Fault is either resolved or flagged for reinspection.









Activity Diagram:







7.1.6. Use Case 6: Approve New User and Assign Roles

Actor(s): Farm Owner, Cloud System (AWS)Preconditions:

A new user registration request exists in the system.

Main Flow:

Farm Owner opens the User Management tab.

System fetches pending requests from the cloud.

Owner reviews user details.

Owner selects role and approves the user.

The system updates user records and notifies user.

Alternate Flows:

If role invalid, show error.

If request is rejected, delete it.

If offline, queue for later sync.

Postconditions:

New users added to the system with appropriate role.



Activity Diagram:



7.2 Requirements

#

Requirement Description

Use Case Generated From

1

The system shall allow the farmer to view real-time plant health and irrigation logs for each zone.

Use Case 1 (View Crop Health and Irrigation Status)

2

The system shall cache data and show an "offline" mode if the Cloud System is unavailable.

Use Case 1 (View Crop Health and Irrigation Status)

3

The system shall allow the farmer to send irrigation commands to specific zones via the dashboard.

Use Case 2 (Send Manual Irrigation Command)

4

The system shall update the dashboard with acknowledgment status from the cloud after a command is sent.

Use Case 2 (Send Manual Irrigation Command)

5

The system shall retry MQTT command if the first transmission fails.

Use Case 2 (Send Manual Irrigation Command)

6

The system shall analyze plant health using TensorFlow Lite AI model.

Use Case 3 (Autonomous Irrigation Decision)

7

The system shall retrieve real-time weather forecast from an external Weather API.

Use Case 3 (Autonomous Irrigation Decision)

8

The system shall fall back to rule-based irrigation logic when AI or weather services fail.

Use Case 3 (Autonomous Irrigation Decision)

9

The system shall compute and issue autonomous irrigation decisions and log the outcome.

Use Case 3 (Autonomous Irrigation Decision)

10

The system shall detect alert conditions (e.g., low moisture, failed irrigation) and notify the farmer.

Use Case 4 (Send Critical Alert to Farmer)

11

The system shall send notifications through Firebase Cloud Messaging.

Use Case 4 (Send Critical Alert to Farmer)

12

The system shall retry failed alerts when the device is offline and log them locally.

Use Case 4 (Send Critical Alert to Farmer)

13

The system shall allow farmers to manually report an issue via the dashboard.

Use Case 5 (Handle Maintenance Fault Report)

14

The system shall detect system faults and notify the assigned maintenance worker.

Use Case 5 (Handle Maintenance Fault Report)

15

The system shall allow maintenance workers to update repair status and notes.

Use Case 5 (Handle Maintenance Fault Report)

16

The system shall prompt a recheck if the issue is not resolved or confirmation is missing.

Use Case 5 (Handle Maintenance Fault Report)

17

The system shall allow the farm owner to review pending user registrations.

Use Case 6 (Approve New User and Assign Roles)

18

The system shall enable the owner to assign user roles (e.g., worker, farmer).

Use Case 6 (Approve New User and Assign Roles)

19

The system shall notify the user of approval and queue updates for offline sync.

Use Case 6 (Approve New User and Assign Roles)

20

The system shall validate selected roles and reject requests with errors.

Use Case 6 (Approve New User and Assign Roles)



7.3 Dynamic behavior of architecture







































































































































































































































































































































































































































































































































Security and Privacy Considerations













Threat Modeling

Data Interception:

Potential Threat: Data sent between the ESP32 devices and the cloud could be intercepted by malicious actors.

Countermeasures:

All data transmitted between ESP32 devices and the cloud is encrypted using SSL/TLS.

MQTT over TLS or HTTPS for secure communication ensures end-to-end encryption.

API gateway with token-based authentication ensures only authorized requests can interact with the cloud.

Unauthorized Access:

Potential Threat: Unauthorized users might gain access to the cloud services or sensitive data (e.g., sensor data, control commands).

Countermeasures:

OAuth 2.0 for secure, token-based user authentication when interacting with the cloud API.

Role-based access control (RBAC) for controlling which users have access to specific data or resources within the cloud system.

Multi-factor Authentication (MFA) for cloud platform logins and sensitive operations.

Denial of Service (DoS) Attacks:

Potential Threat: A DoS attack could flood the cloud services or the server with traffic, making it unavailable.

Countermeasures:

Use cloud DDoS protection services such as AWS Shield or Google Cloud Armor to prevent service disruptions.

Rate-limiting and request throttling are implemented at the API Gateway to prevent abusive traffic and ensure fair usage.

Encryption and Authentication

Encryption:

In Transit:

Data transmitted between ESP32 devices, the cloud, and the server is encrypted using TLS/SSL to prevent interception.

The MQTT messages sent from the ESP32 to the cloud are encrypted with TLS for secure data transmission.

At Rest:

Sensor data and control instructions stored in the cloud (e.g., AWS DynamoDB, Google Firestore) are encrypted at rest using platform-level encryption mechanisms (e.g., AWS KMS or Google Cloud Key Management).

Backups of critical data are also encrypted to prevent unauthorized access.

Authentication:

User Authentication:

Users accessing the cloud system (e.g., farm managers) are authenticated using OAuth 2.0 or JWT tokens for secure, stateless access to the cloud.

API authentication ensures that only authorized services (e.g., server-to-cloud, ESP32-to-cloud) can interact with cloud resources.

Device Authentication:

Each ESP32 device is authenticated using X.509 certificates or pre-shared keys for secure communication with the cloud.

Access Control

Role-Based Access Control (RBAC):

System Access Control: Access to cloud resources is governed by RBAC. Different roles (e.g., Admin, User, Sensor roles) are assigned with specific permissions.

Admin: Full access to configure devices, manage user access, and view system-wide data.

User: Limited access to sensor data and real-time reports.

Sensor: Only interacts with the cloud for sending data, without access to configuration settings.

Granular Permissions:

Access to specific data (e.g., sensor readings, command instructions) is limited to authorized roles. For example, farm managers may have access to all historical data, but field workers only have access to live data.

Data Privacy

Compliance with Regulations:

If personal data is involved (e.g., farm worker identification, location tracking), compliance with GDPR, CCPA, or local data privacy laws must be ensured.

Data Minimization: Only necessary data (e.g., sensor data) is collected. Personal information is not stored unless necessary for system functionality or required by regulation.

Data Retention Policies: Data is retained only for the period necessary for operational purposes (e.g., 30 days for real-time monitoring data). Historical data can be archived and deleted periodically to comply with privacy regulations.

Data Anonymization: If required, personally identifiable information (PII) is anonymized or pseudonymized when stored or transmitted to ensure privacy.

Sensitive Data Handling:

Sensor Data: The system processes only environmental data (e.g., soil moisture, temperature). No personally identifiable information (PII) is captured unless explicitly required.

User Data: For users interacting with the system, only necessary information (e.g., name, email, user credentials) is collected, and this is stored securely using encrypted databases.

Summary of Security for Major Components

Edge Devices (ESP32):

Use secure boot and signed firmware updates to ensure the integrity of the device.

Communication between the ESP32 and the cloud is secured using MQTT over TLS for data transmission.

Cloud Infrastructure:

The cloud system uses OAuth 2.0 for secure user authentication and TLS encryption for all communications with IoT devices and external services.

Data storage in cloud databases (e.g., DynamoDB, Firestore) is encrypted both at rest and in transit to maintain data integrity and confidentiality.

Server:

The server that processes data from the cloud also uses secure communication channels (e.g., HTTPS), and sensitive data is encrypted using AES encryption when stored.

Role-based access is enforced to ensure that only authorized personnel can access and modify server-side data.



Summary of Security and Privacy Considerations:

The system has been designed with security-by-design in mind, employing encryption at both data transit and rest to protect data from unauthorized access.

Authentication is handled securely with industry-standard OAuth 2.0 and JWT tokens to ensure only authorized access to the cloud and server systems.

Access control is strictly enforced using RBAC, allowing different user roles to access only the necessary data.

Data privacy is ensured through compliance with GDPR and other local data privacy laws, with measures such as data minimization and anonymization in place.



9. Sustainability and Environmental Impact









9.1 Resource Efficiency

Resource efficiency is crucial to minimize energy consumption, reduce waste, and make efficient use of available resources. For this system, you can focus on the following points:

Energy Efficiency in IoT Devices:

Low-power IoT Devices: The ESP32 devices are energy-efficient by design, using low power when idle or in sleep mode. This reduces overall energy consumption, which is particularly important in IoT networks with many devices.

Power-saving features: Use deep sleep modes for the ESP32 when not actively sending data. By utilizing low-energy communication protocols (e.g., MQTT over Wi-Fi), the devices will only transmit data when necessary, saving power.

Energy Efficiency in Cloud Operations:

Cloud-based scaling: By leveraging serverless computing (e.g., AWS Lambda, Google Cloud Functions), energy consumption is optimized. Serverless computing only uses energy when functions are triggered, as opposed to running constantly. This significantly reduces the carbon footprint by minimizing unnecessary processing power.

Virtualization and Containers: Deploying applications on virtual machines or containers (e.g., AWS EC2, Google Kubernetes Engine) enables optimal resource allocation, reducing the need for dedicated, underutilized hardware.

Efficient Networking:

Compression and Efficient Data Transmission: Data transmitted from the IoT devices to the cloud is optimized for minimal bandwidth use. Using MQTT, a lightweight messaging protocol, ensures that network bandwidth is minimized as it is designed for low-latency and small data payloads.

Edge processing: Some of the data can be processed locally on the ESP32 (e.g., filtering or aggregating sensor data) before sending it to the cloud, reducing the amount of data transmitted and minimizing network load.

The AI module Resource Efficiency:

The AI module is designed to process plant images captured from the field. The system employs lightweight machine learning models which reduce the  computational requirements for analysis thus decreasing energy usage.



9.2 Life Cycle Considerations

Life cycle considerations focus on the environmental impact of hardware over its entire operational lifetime, including its use, maintenance, and eventual disposal.

Hardware Lifetime:

IoT Devices (e.g., ESP32): The ESP32 devices are designed to have long operational lifetimes due to their low power consumption and reliability. Given that these devices are built for embedded applications, they are expected to last for several years without needing replacement.

Sensor Lifespan: Sensors used in the system (e.g., soil moisture sensors, temperature sensors) typically have lifespans of 5–10 years, depending on environmental conditions. Regular maintenance and recalibration are required to ensure their accuracy.

Maintenance:

Remote Maintenance: The system supports remote diagnostics and software updates, reducing the need for physical interventions and the associated carbon footprint. Devices like the ESP32 can receive over-the-air (OTA) firmware updates, ensuring that they remain functional without the need for manual intervention.

Energy-efficient Design: By ensuring that devices operate with minimal energy requirements and are optimized for low-power states, hardware maintenance is reduced, leading to fewer failures and longer operational periods.

Disposal and Recycling:

Electronic Waste Management: At the end of their operational life, IoT devices and sensors should be disposed of responsibly. Many components of ESP32 devices, like microcontrollers, can be recycled as part of electronic waste recycling programs.

Circular Economy Approach: By using components that are easy to recycle and reducing waste, the system can contribute to a circular economy, ensuring that components like the sensors, microcontrollers, and batteries are properly recycled.

The Ai Module Life Cycle: 

The AI operates only upon receiving  new images which helps extend the operational period of the system by avoiding continuous processing. The system operates with  minimal hardware strain because of its lightweight processing which also reduces future maintenance needs.





9.3 Scalability

Scalability refers to the ability to expand the system without significantly increasing resource consumption or negatively impacting the environment.

Cloud Scalability:

Elastic Scaling: The system is designed to scale dynamically based on demand. Cloud services (e.g., AWS Auto Scaling, Google Kubernetes Engine) allow the system to scale up during high demand (e.g., increased sensor data or more devices) and scale down when demand is low, ensuring energy efficiency.

Serverless Architecture: By adopting serverless computing, where the cloud only uses computing resources when triggered (e.g., through AWS Lambda or Google Cloud Functions), scalability is achieved without wasting resources during periods of inactivity.

Modular IoT Devices:

Scalable IoT Deployment: The system’s modular nature allows the addition of more ESP32 devices or sensors without excessive infrastructure changes. Devices can be added to the network as needed, and the cloud infrastructure will automatically scale to handle the increased data flow. This eliminates the need for over-provisioning.

Efficient Data Aggregation: As the system scales, local processing via the ESP32 devices can reduce the amount of raw data sent to the cloud. This ensures that adding more devices won’t exponentially increase the data transmitted, thus optimizing bandwidth and cloud resources.

Resource Efficiency in Cloud Scaling:

Shared Resources: By using containerized or virtualized cloud environments, the system can efficiently allocate computing resources based on demand. This prevents over-provisioning, which reduces energy usage and ensures that no excess hardware is running when not needed.

Decentralized Architecture: The system can handle different regions or locations by decentralizing processing tasks. By managing clusters in different regions (e.g., using AWS Regions or Google Cloud Zones), the system can expand globally without additional hardware requirements.

The AI Module Scalability:

The  AI classification system provides straightforward scalability to new farm zones and expanded agricultural fields without causing substantial increases in energy  usage or system management overhead. The system's design allows future growth to be sustainable while maintaining environmental  responsibility.



Summary of Sustainability and Environmental Impact:

Resource Efficiency: The system uses low-power IoT devices, optimizes cloud computing resources through serverless and virtualized architecture, and minimizes network bandwidth by using efficient data protocols and edge processing.

Life Cycle Considerations: Devices are designed for long operational lifetimes with minimal maintenance and are easily recyclable at the end of their life. The system reduces hardware waste and energy consumption through remote maintenance and OTA updates.

Scalability: The system is designed to scale in a cloud-native fashion, allowing it to expand without excessive resource consumption. The modularity of IoT devices and dynamic cloud scaling ensures minimal environmental impact as the system grows.



10. Testing and Validation Strategy













10.1 Test Methodologies

Testing is crucial to ensure the system’s reliability, functionality, and scalability. Different levels of testing are employed at various stages of development:

Unit Tests:

Purpose: Test individual components (e.g., ESP32 sensor readings, data processing functions) to ensure they work as expected.

Tools: Use frameworks such as JUnit (for Java) or PyTest (for Python) to test the individual software components.

Example: Unit test for the MQTT handler on the ESP32 to ensure correct data is sent to the cloud.

Integration Tests:

Purpose: Verify that different components (e.g., IoT devices, cloud communication, server processing) interact correctly.

Tools: Tools like Postman (for API testing) and Mockito (for mocking dependencies) can be used for integration tests.

Example: Integration test for the communication between ESP32 and AWS IoT Core to verify proper data transmission and reception.

System Tests:

Purpose: Test the entire system to ensure that all components work together as expected. This includes testing end-to-end workflows (e.g., sensor data collection, cloud processing, sending instructions back to ESP32).

Tools: Selenium (for UI testing), JUnit, or Cypress (for end-to-end testing).

Example: Testing the complete data flow from sensor data collection to cloud storage and back to the ESP32 for action (e.g., adjusting irrigation based on data analysis).

Acceptance Tests:

Purpose: Validate that the system meets the business requirements and that users can perform the required functions (e.g., real-time monitoring of sensor data, controlling irrigation via cloud interface).

Tools: Cucumber (for behavior-driven testing) or Jest (for front-end testing).

Example: Verify that the system provides real-time data visualization for users on the dashboard and allows for remote control of irrigation systems.

The AI Module Tests:Each function (e.g., image preprocessing, CNN prediction, decision logic) will be tested individually with sample input images and mock sensor data to verify correct output.Test the full AI workflow: receiving an image → preprocessing → classification → decision-making → command generation.Simulate a full system environment using uploaded images and sensor data to validate that irrigation commands are generated correctly across multiple farm zones.Ensure that the AI system correctly identifies plant health and outputs the appropriate irrigation decision in at least 90% of tested cases.





10.2 Automation

Automation of testing and deployment is a core part of modern software development. The aim is to continuously integrate and deploy code, ensuring that any issues are caught early.

Continuous Integration (CI):

Purpose: Automatically build and test code whenever changes are made to the repository.

Tools: Use Jenkins, GitLab CI, or CircleCI to automate build and test pipelines.

Example: When code is pushed to a Git repository, the CI pipeline automatically runs unit tests on the cloud code and the firmware for the ESP32. Any failure triggers an alert, and developers can fix issues immediately.

Continuous Deployment (CD):

Purpose: Automatically deploy the application to production after passing automated tests, ensuring new features and fixes are available to users quickly.

Tools: Use AWS CodePipeline, GitLab CI/CD, or Kubernetes for automated deployment.

Example: After successful testing, the new code for cloud processing functions is automatically deployed to AWS Lambda or Google Cloud Functions without manual intervention.

Testing scripts will automate image uploading and classification verification.

Decision logic will be tested using automated test cases simulating soil moisture and temperature variations.

CI/CD pipelines are not necessary for the current academic deployment but can be considered for future expansions.



10.3 Performance & Stress Testing

To ensure the system can handle expected workloads, stress and performance testing are critical to uncover potential bottlenecks, crashes, or slowdowns under heavy loads.

Performance Testing:

Purpose: Measure the performance of the system under typical and peak load conditions (e.g., response times, throughput).

Tools: Use tools like JMeter, LoadRunner, or AWS CloudWatch to monitor system performance.

Example: Measure the response time of the cloud system when receiving sensor data from multiple ESP32 devices simultaneously.

Stress Testing:

Purpose: Push the system beyond its expected load to understand its breaking point and ensure that it fails gracefully.

Tools: Gatling, Artillery, or custom scripts for simulating high data influx.

Example: Simulate a large number of simultaneous connections to the cloud from thousands of ESP32 devices, ensuring that the system can scale effectively and handle unexpected spikes in traffic.

Scalability Testing:

Purpose: Ensure that the system scales without degradation in performance as more devices, users, or data are added.

Tools: Use AWS Auto Scaling and Google Cloud’s Autoscaler to test how the cloud infrastructure scales up and down.

Example: Evaluate how adding new sensors and devices affects system performance, ensuring that the system remains responsive even with large numbers of devices.

Measure the average inference time for each image classification.Expected performance: ≤ 200 ms per image.

Stress testing by simulating simultaneous uploads of 10+ images to verify that system response remains under 500 ms per classification and decision cycle.



10.4 User Acceptance Testing (UAT)

User Acceptance Testing ensures that the system meets user expectations and business needs before going live.

Who Will Conduct UAT:

UAT will be conducted by end users (e.g., farm managers, administrators) who will interact with the system to ensure it fulfills the business requirements.

A test team from the project group, along with selected stakeholders and users, will perform UAT to ensure the system works as intended.

Team members will simulate farmer actions by uploading images of healthy, stressed, and dead plants.

Validation that AI correctly identifies the plant status and generates the appropriate watering commands.

Success criteria:

≥ 90% correct health classification.

Correct corresponding irrigation decision based on AI and sensor input.



Success Criteria:

The system should allow farm managers to monitor sensor data in real-time, adjust irrigation remotely, and receive system alerts for operational issues.

Success Criteria: All major workflows should function as expected with minimal user errors. The system should be able to process a given number of devices and users without performance degradation.

Feedback Loop:

After testing, feedback will be gathered from users, and any issues identified during UAT will be addressed. Continuous feedback from real users will be incorporated into the system, especially for improvements to the user interface or usability.

AI module: 

As an academic project, no formal regulatory testing is required.

Good practices such as secured data transfer and structured testing processes are followed to maintain quality and system integrity.





10.5 Regulatory or Certification Testing

If applicable, ensure the system meets regulatory standards or certifications required for IoT systems or data handling.

IoT Security Certifications:

Ensure compliance with standards like ISO/IEC 27001 for information security and NIST SP 800-53 for secure cloud architecture.

Data Privacy and Compliance:

GDPR: If any personal data is handled, ensure that the system complies with GDPR or similar privacy regulations, ensuring data is processed and stored securely.

Local Regulations: Ensure compliance with any relevant local regulations (e.g., CCPA for California residents, HIPAA for health-related data if applicable).

Environmental Certifications:

The hardware and cloud services should adhere to environmental sustainability certifications, such as Energy Star for efficient devices or ISO 14001 for sustainable operations.



Summary of Testing and Validation Strategy:

Test Methodologies: The system will undergo unit, integration, system, and acceptance tests to ensure functionality and performance.

Automation: Continuous integration and deployment pipelines will automate testing and deployment, ensuring smooth code delivery.

Performance & Stress Testing: Tools like JMeter and Gatling will be used to test the system’s performance under load, ensuring it can scale.

User Acceptance Testing: UAT will be conducted by end users to ensure the system meets user expectations.

Regulatory Testing: The system will comply with necessary certifications, such as GDPR for privacy and ISO/IEC 27001 for security.



11. Declaration of use of AI



Searching for communication details for HW architecture







Making sure that our communication is consistent





Making sure we are not using the wrong load cell





Checking for grammatical errors







I used AI to help improve the clarity of my system diagram. I asked how to properly show the AI module that classifies plant images before results are sent to the dashboard:









To improve the grammar and clarity of my written section, I used AI assistance. I asked for corrections specifically without changing the structure or technical content of the text:







To improve the grammar and flow of Section 6.3 – AI-Based Plant Health Monitoring System I used AI support. The goal was to correct grammar errors without changing the technical meaning or structure of the content:







To improve the grammar and sentence structure of Section 6.1, I used AI to review and correct the paragraph without changing its technical content. The AI helped me fix spacing issues:





























Appendix

Coder AI part 1:

# STEP 1: Install and Import Packages

!pip install -q tensorflow opencv-python-headless



import os, cv2, numpy as np, pandas as pd

import tensorflow as tf

from sklearn.preprocessing import LabelEncoder

from sklearn.metrics import classification_report, confusion_matrix

from tensorflow.keras.applications import EfficientNetB0

from tensorflow.keras.applications.efficientnet import preprocess_input

from tensorflow.keras.models import Model

from tensorflow.keras.layers import Input, GlobalAveragePooling2D, Dense, Dropout

from tensorflow.keras.utils import to_categorical

from tensorflow.keras.optimizers import Adam

from tensorflow.keras.preprocessing.image import ImageDataGenerator

from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau



# STEP 2: Load and Preprocess Data

train_df = pd.read_csv("/content/train_data.csv")

test_df = pd.read_csv("/content/test_data.csv")



IMG_SIZE = (224, 224)



def load_images(df):

    images, labels = [], []

    for _, row in df.iterrows():

        img = cv2.imread(row['image_path'])

        if img is not None:

            img = cv2.resize(img, IMG_SIZE)

            img = preprocess_input(img.astype(np.float32))

            images.append(img)

            labels.append(row['health_status'])

    return np.array(images), np.array(labels)



X_train, y_train = load_images(train_df)

X_test, y_test = load_images(test_df)



# STEP 3: Encode Labels & Define Class Weights

encoder = LabelEncoder()

y_train_enc = to_categorical(encoder.fit_transform(y_train))

y_test_enc = to_categorical(encoder.transform(y_test))



label_to_index = dict(zip(encoder.classes_, encoder.transform(encoder.classes_)))

class_weight_dict = {

    label_to_index['Dead']: 3.0,

    label_to_index['Healthy']: 1.5,

    label_to_index['Stressed']: 1.0

}



# STEP 4: Augmentation

BATCH_SIZE = 32

datagen = ImageDataGenerator(

    rotation_range=30,

    zoom_range=0.3,

    width_shift_range=0.2,

    height_shift_range=0.2,

    brightness_range=(0.7, 1.3),

    horizontal_flip=True

)

datagen.fit(X_train)



# STEP 5: Build EfficientNetB0 Model

base_model = EfficientNetB0(weights='imagenet', include_top=False, input_tensor=Input(shape=(224, 224, 3)))

for layer in base_model.layers[:100]:

    layer.trainable = False



x = base_model.output

x = GlobalAveragePooling2D()(x)

x = Dropout(0.4)(x)

output = Dense(3, activation='softmax')(x)



model = Model(inputs=base_model.input, outputs=output)

model.compile(

    optimizer=Adam(1e-4),

    loss=tf.keras.losses.CategoricalCrossentropy(label_smoothing=0.1),

    metrics=['accuracy']

)



# STEP 6: Train the Model

early_stop = EarlyStopping(monitor='val_accuracy', patience=7, restore_best_weights=True)

lr_reduce = ReduceLROnPlateau(monitor='val_accuracy', factor=0.3, patience=3, verbose=1)



history = model.fit(

    datagen.flow(X_train, y_train_enc, batch_size=BATCH_SIZE),

    validation_data=(X_test, y_test_enc),

    epochs=40,

    class_weight=class_weight_dict,

    callbacks=[early_stop, lr_reduce]

)



# STEP 7: Evaluate and Save

loss, acc = model.evaluate(X_test, y_test_enc)

print(f"\n Final Test Accuracy: {acc:.4f}")



y_pred = model.predict(X_test)

y_pred_labels = encoder.inverse_transform(np.argmax(y_pred, axis=1))



print("\nClassification Report:\n", classification_report(y_test, y_pred_labels))

print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred_labels, labels=encoder.classes_))



model.save('/content/plant_health_efficientnetb0.h5')

Code AI part 2: 

import pandas as pd

import numpy as np

from sklearn.preprocessing import LabelEncoder, StandardScaler

from sklearn.metrics import classification_report, confusion_matrix

from tensorflow.keras.models import Sequential

from tensorflow.keras.layers import Dense, Dropout

from tensorflow.keras.utils import to_categorical

from tensorflow.keras.callbacks import EarlyStopping

from tensorflow.keras.optimizers import Adam



# Load the balanced dataset that includes health_status

train_df = pd.read_csv("/content/balanced_train_data.csv")

test_df = pd.read_csv("/content/balanced_test_data.csv")



# Step 1: Encode health_status into numbers

health_encoder = LabelEncoder()

train_df["health_encoded"] = health_encoder.fit_transform(train_df["health_status"])

test_df["health_encoded"] = health_encoder.transform(test_df["health_status"])



# Step 2: Prepare input features (sensors + plant health)

features = ['soil_moisture', 'temperature', 'humidity', 'health_encoded']

X_train = train_df[features]

X_test = test_df[features]



# Step 3: Normalize features

scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)

X_test_scaled = scaler.transform(X_test)



# Step 4: Encode irrigation_decision labels

label_encoder = LabelEncoder()

y_train_enc = to_categorical(label_encoder.fit_transform(train_df["irrigation_decision"]))

y_test_enc = to_categorical(label_encoder.transform(test_df["irrigation_decision"]))



# Step 5: Build the model

model = Sequential([

    Dense(64, activation='relu', input_shape=(4,)),  # now using 4 features

    Dropout(0.3),

    Dense(32, activation='relu'),

    Dropout(0.3),

    Dense(3, activation='softmax')

])

model.compile(optimizer=Adam(learning_rate=0.001),

              loss='categorical_crossentropy',

              metrics=['accuracy'])



# Step 6: Train

early_stop = EarlyStopping(monitor="val_accuracy", patience=5, restore_best_weights=True)

history = model.fit(X_train_scaled, y_train_enc,

                    validation_data=(X_test_scaled, y_test_enc),

                    epochs=40,

                    batch_size=32,

                    callbacks=[early_stop],

                    verbose=1)



# Step 7: Evaluate

loss, acc = model.evaluate(X_test_scaled, y_test_enc)

print(f"\n Final Accuracy: {acc:.4f}")



y_pred_probs = model.predict(X_test_scaled)

y_pred_labels = label_encoder.inverse_transform(np.argmax(y_pred_probs, axis=1))

true_labels = test_df["irrigation_decision"]



print("\n Classification Report:\n", classification_report(true_labels, y_pred_labels))

print("\n Confusion Matrix:\n", confusion_matrix(true_labels, y_pred_labels, labels=label_encoder.classes_))



# Step 8: Save model

model.save("/content/final_irrigation_decision_model.h5")

