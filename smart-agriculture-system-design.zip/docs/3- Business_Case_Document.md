# 3- Business_Case_Document

King Fahad University of Petroleum and Minerales 

COE384 

Business Case



Project Name:

Smart Agricultural Monitoring and Control System

Team Number:

Team 6

Date:

20/4/2025

Release:

Draft/Final

Student 1 Name:

Khalid Alsaif

Signature:



Student 1 ID: 

[student ID removed]





Author 2 Name:

Saud Alsaleem

Signature:



Student 2 ID: 

[student ID removed]





Author 3 Name:

Mojtaba Alsaad

Signature:



Student 3 ID: 

[student ID removed]





Author 4 Name:

Kureym Alzarea

Signature:



Student 4 ID: 

[student ID removed]





Author 5 Name:

Ahmed Alghamdi

Signature



Student 5 ID: 

[student ID removed]





Document Number:

T242-COE384-BC-001

Revision History

Revision Date

Previous Revision Date

Summary of Changes

Changes Marked

20/4/2025

-





29/04/2025

20/04/2025

In the executive summary, we started by talking about Vision 2030 as advised from Thamer’s review



29/04/2025

20/04/2025

In the executive summary, we deleted the sentence ‘segmented into 10m x 10m zones’ as advised from Thamer’s review since it has not been mentioned in the document



29/04/2025

20/04/2025

In the Business options, we mentioned what the system, in the do nothing, will have rather than what it will miss, as advised by Thamer’s review. We also added more details as Moaz advised. 



29/04/2025

20/04/2025

In the benefit section, we added benefits for the do-nothing option as advised by Thamer and Moaz. Also fixed inconsistency problem mentioned by Abdullah Arafat.  



29/04/2025

20/04/2025

In the timescale section, we did major changes



29/04/2025

20/04/2025











































Approvals

This document requires the following approvals.  A signed copy should be placed in the project files.

Name

Signature

Title

Date of Issue

Version

Dr. Akram 

Fadhl N. 

Ahmed





Professor at Computer 

Engineering in KFUPM



29/4/2025

002



























Distribution

This document has been distributed to:

Name

Title

Date of Issue

Version

Dr. Akram Fadhl N. Ahmed

Professor at Computer Engineering in KFUPM

29/4/2025

002

Abdulaziz Ashy









COE Student at KFUPM

20/4/2025

001

Moaz Abdelaziz 









COE Student at KFUPM

20/4/2025

001

Abdullah Al-Arafat 











COE Student at KFUPM

20/4/2025

001

Ziad Algamdi 









COE Student at KFUPM

20/4/2025

001

Thamer Alotaibi 









COE Student at KFUPM

20/4/2025

001





















                                                       Contents

Executive Summary4

Reasons4

Business Options4

Expected Benefits5

Expected Dis-benefits5

Timescale5

Costs6

Investment Appraisal6

Major Risks6







































Executive Summary



This business case assumes deployment over a 200m x 200m farming area, segmented into 10m x 10m zones. Furthermore, it explores three strategic options for enhancing agricultural efficiency through smart farming technologies: Doing nothing, implementing a basic monitoring system, and fully implementing an integrated smart agricultural monitoring and control solution.

Rooted in Saudi Vision 2030, the project supports the objectives for smart city development and the security of food and water resources.

The "Do Nothing" approach requires no upfront investment but leads to an estimated annual loss of 24,800 SAR per farm due to inefficient water usage and decreased crop yield.

The Basic Monitoring System requires an initial investment of 29,300 SAR, with ongoing annual costs of 5,000 SAR. It offers modest annual savings of 6,266 SAR and a low ROI of 4.3%, with a negative NPV of -23,818 SAR over 5 years, making it a less viable long-term solution.

The "Complete System" requires 106,200 SAR upfront and 15,000 SAR/year in operations, but delivers strong benefits: 30% water savings, 15% yield increase, and reduced manual labor. It achieves an ROI of 23.4%, a payback period of 5 years, and a positive NPV of 1,171 SAR, making it the most cost-effective and impactful option.

Funding for the complete system is proposed through a combination of Saudi Vision 2030 agricultural grants, private investment, tech partnerships (e.g., Solutions by STC), and low-interest loans.

Based on long-term benefits and financial viability, this business case recommends proceeding with the full implementation of the Smart Agricultural Monitoring and Control System.





























































































Reasons:

Companies might choose our smart irrigation system for several key reasons:

1.    Optimized Water Usage: Saudi Arabia’s water resources are extremely limited, making it critical to minimize waste. Our system uses advanced sensors and an AI-driven module to analyze real‑time soil and environmental data, ensuring each section of the farm receives precisely the amount of water it needs—no more, no less.

2.    Alignment with Government Policies & Sustainability Goals: Under Saudi Vision 2030, the Ministry of Environment, Water and Agriculture (MEWA) emphasizes modernizing irrigation to protect dwindling groundwater reserves. Implementing our solution helps companies comply with national sustainability targets and demonstrate environmental responsibility.

3.    Improved Crop Quality: Both over‑ and under‑irrigation can damage crops, leading to financial losses and wasted resources. Our AI estimates the optimal water requirement for each crop type, guaranteeing healthy growth and maximizing yield quality.

4.    Comprehensive Crop Insights: Effective farm management relies on accurate, up‑to‑date information. We store all crop‑health metrics and water‑usage data in the cloud, accessible via an intuitive dashboard—locally or remotely—so you can make informed decisions anytime, anywhere.

5.    Reduced Labor Requirements: Full automation means fewer on‑site personnel are needed to monitor and operate irrigation systems, lowering labor costs and reducing the logistical burden of workforce management.









6.    Scalable Farm Management: Managing large or multiple farms traditionally demands significant effort. Our system’s automation and centralized monitoring let you expand acreage without sacrificing performance, water efficiency, or crop quality.

7.    Rapid Fault Detection & Alerts: Human error and system malfunctions can go unnoticed, causing crop damage and water loss. Our solution continuously monitors system health, instantly flagging anomalies and sending alerts so issues can be resolved before they escalate.

8.    Overall Cost Savings:By cutting water waste, reducing labor needs, and preventing crop   losses through faster error detection, our smart irrigation system delivers substantial cost reductions across all operational areas.



Business Options

Do nothing:

Stay with the current system.

Basic Version:

In this system, a Microcontroller network will collect data from soil and environmental sensors. Then, Microcontrollers will calculate the required amount of water based on sensor reading. Also, the system will have a simple dashboard for displaying key metrics.

Complete Version:

The system features a network of microcontrollers that collect data from moisture, temperature, and pressure sensors. These microcontrollers locally filter the data before transmitting it to the cloud, where it is stored and processed by an AI agent to ensure accuracy. Once the analysis is complete, the results are sent back to the microcontrollers, which then control water valves connected to irrigation pipes, automatically adjusting water flow based on the findings.

Additionally, a monitoring system equipped with cameras captures images of the crops, which are uploaded to the cloud and analyzed by an AI-powered image recognition module. If any dead or unhealthy plants are detected, the system sends a notification to the user.

The system also offers data-driven recommendations to enhance crop quality, along with detailed maintenance logs and reports. All functionalities can be monitored and controlled remotely through a dashboard or a mobile application.









































































































































































 Expected Benefits





Do Nothing:



Save the money of building the system to other purposes

Do not take the risk of acquiring new system

Stay with the simple traditional system 

Basic Version:



5–10% water savings by automating watering triggers based on soil moisture rather than fixed schedules.

Small yield gains around 3–5% from better-timed irrigation.

Reduced labor for field‑moisture checks, lowering operational effort.



Compleat Version:



30–45% water savings through AI‑driven irrigation control (±5% variance).



10–15% increase in crop yield and quality via real‑time monitoring and early 

disease detection.

30–50% reduction in labor & maintenance costs by automating routine checks and predictive maintenance alerts.

 

Enhanced decision‑making through 24×7 cloud dashboard visibility.





Alignment with sustainability & regulatory goals.

 







 



Expected Dis-benefits





Do Nothing:

Continued inefficient water use with no precision control, perpetuating up to 30% unnecessary water consumption.

No improvement in crop yield or quality (Risks of stagnant or declining productivity).

Ongoing high labor costs for manual irrigation checks and maintenance.

Failure to meet evolving sustainability and regulatory targets for water conservation.







Basic Version:

Upfront costs for purchasing and installing sensors, wiring, and basic control panels.





Continued reliance on manual data reading potential for human error and a learning curve.





Regular calibration and occasional sensor replacement required.











Compleat Version:



High initial capital outlay for sensors, edge hardware, AI model development, and cloud subscriptions.

 

Training costs and temporary productivity dips as staff adapt to new systems.





Dependence on reliable network connectivity (risk of service interruptions).



Ongoing costs for cloud services, software updates, and advanced hardware maintenance.





 

 









Timescale

The Timescale of our system is 5 years.  

























































Costs



The following table summarizes the estimated costs of the project under three business options: Do Nothing, Basic Version, and Complete Version. It includes the initial investment required for hardware, software, development, and installation, as well as estimated annual operations and maintenance costs. The costs are estimated based on realistic market pricing for components, services, and development labor. 

1. Do Nothing Option 

Component

Quantity and Calculation

Total Cost  (SAR)

Notes

Hardware Components

No hardware required

0

No new hardware

Software Development

No development

0



Installation

No installation required

0



Cloud Subscription

No cloud services

0



Operating Costs (Annual)

Workers

20 × 5,000 SAR = 100,000 SAR/month 

1,200,000 SAR/year



Farmers

5 × 7,000 SAR = 35,000 SAR/month 

420,000 SAR/year



Water Consumption

25 m³/day × 30 × 11 SAR = 8,250 SAR/month 

99,000 SAR/year

0% water saving

Electricity

1,000 SAR/month 

12,000 SAR/year



Total O&M Cost Annually

Total Variable Cost per System

1,731,000 SAR

0 SAR



5-Year Interest Calculation (5%) for Do Nothing Option:

NPV = 1,731,000 × [(1 - (1 + 0.05)^-5) / 0.05] = 7,487,174 SAR

Total 5-Year Cost = 0 + 7,487,174 = 7,487,174 SAR





2. Basic Version 

Component

Quantity and Calculation

Total Cost (SAR)

Notes

Hardware Components

Microcontrollers

100 pieces × 80 SAR each

8,000 SAR

1 per segment

Sensors

1,000 pieces × 10 SAR each

10,000 SAR

10 per segment

Valves

100 pieces × 150 SAR each

15,000 SAR

1 per segment

Hardware Subtotal



33,000 SAR



Installation (Hardware)

4 workers × 5,000 × 2 months



40,000 SAR



Wiring, devices 

Software Components

Dashboard Development



1 dashboard project × 10,000 SAR

10,000 SAR

Basic display system Web /mobile dashboard

Training

2 technicians × 7,000 SAR ×1 month 

14,000 SAR



Cloud Setup

Local server

0 SAR

Minimal cloud

Operating Costs (Annual)

Workers

10 × 5,000 SAR = 50,000 SAR/month 

600,000 SAR/year



Farmers

3 × 7,000 SAR = 21,000 SAR/month 

252,000 SAR/year



Water Consumption

23.125 m³/day × 30 × 11 SAR = 7,631 SAR/month 

91,572 SAR/year

~7.5% water saving

Electricity

1,200 SAR/month 

14,400 SAR/year



Total O&M Cost Annually

Total Variable Cost per System

957,972 SAR

97,000 SAR



5-Year Interest Calculation (5%) for Basic Version:

NPV = 957,972 × [(1 - (1 + 0.05)^-5) / 0.05] ≈ 4,143,837 SAR

Total 5-Year Cost = 97,000 + 4,143,837 = 4,240,837 SAR



3. Complete Version 

Component

Quantity and Calculation

Total Cost (SAR)

Notes

Hardware Components

Microcontrollers

100 pieces × 80 SAR each

8,000 SAR

1 per segment

Sensors

1,000 pieces × 10 SAR each

10,000 SAR

10 per segment

Valves

100 pieces × 150 SAR each

15,000 SAR

1 per segment

Cameras

100 pieces × 300 SAR each

30,000 SAR

1 per segment (for AI)

Hardware Subtotal



63,000 SAR



Installation

4 workers × 5,000 SAR × 2 months

40,000 SAR

Wiring, camera mounts, devices

Software Development

AI Module Development



1 Full AI system

30,000 SAR

Full plant-health classification + alerting

Dashboard Development



1 Intuitive UI

10,000 SAR

Mobile + Web access dashboard

Training

2 technicians × 7,000 SAR × 1 month 

14,000 SAR

Staff usage training

Cloud Hosting

500 SAR/month ×12 

6,000 SAR/year

Cloud service Firebase + Functions

Operating Costs (Annual)

Farm Workers

5 × 5,000 SAR = 25,000 SAR/month 

300,000 SAR/year



Farmers

1 × 7,000 SAR = 7,000 SAR/month 

84,000 SAR/year



Water Consumption

15.625 m³/day × 30 × 11 SAR = 5,156 SAR/month 

61,872 SAR/year

~37.5% water saving

Electricity

1,500 SAR/month 

18,000 SAR/year

Cloud & local devices

Total O&M Cost Annually

Total Variable Cost per System

469,872 SAR

163,000 SAR



5-Year Interest Calculation (5%) for Complete Version:

NPV=469,872×(0.051−(1+0.05)−5​)≈2,041,570 SAR

Total 5-Year Cost = 163,000 + 2,041,570 = 2,204,570 SAR



Final Summary Table:

Option

Initial Cost (SAR)

Annual Total Cost (SAR)

5-Year Total Cost (SAR)

Do Nothing

0

1,731,000

7,487,174

Basic Version

97,000

957,972

4,143,837

Complete Version

163,000

469,872

2,041,570













































































































































































































Investment Appraisal



Option 1: do nothing (maintain traditional farming practices)

Investment cost: $0, no investment needed

Operational costs: 

200m x 200m farm size

Labor: 1,000 per employee a month, we have 5 so the total is = 60,000 SAR / year

Water: (650 cubic meter per month, 11 SAR per cubic meter) = 85,800 SAR / year



Power: (500 kW per month,  0.18 SAR for 1 kW per month) = 1,080 SAR / year



Total per year = 1,080+85,800 + 60,000 = 146,880 SAR / year















Option 2: implementing a monitoring system and controlling actuators locally

Initial investment:

Operational costs: 

Labor: 1,000 per employee a month, we have 3 so the total is = 36,000 SAR / year

Water: (500 cubic meter per month, 11 SAR per cubic meter) = 66,000 SAR / year

Power: (600 kW per month,  0.18 SAR for 1 kW per month) = 1,296 SAR / year

Total per year = 103,296 SAR / year



















ROI: ((11,266 – 5,00) / 32,300) * 100 = 19.4% 

Payback period:

Year

0

1

2

3

4

5

Investment

32,300

-

-

-

-

-

Cash Flow

-

6,266

6,266

6,266



6,266



6,266



Cumulative

-32,300

-26,034

-19,768

-13,502

-7,236

-970





































































NPV (5%):  = = -2171.5 SAR in 5 years

Break-even-point:  32300 / 6266 = 5.15 years









































































Option 3: fully implementing the system

Initial investment: 80,700 SAR per farm

Operational costs: 15,000 SAR/year

Labor: 1,000 per employee a month, we have 2 so the total is = 24,000 SAR / year

Water: (400 cubic meter per month, 11 SAR per cubic meter) = 52,800 SAR / year

Power: (800 kW per month,  0.18 SAR for 1 kW per month) = 1,728 SAR / year

Total per year = 78,528 SAR / year





















ROI:  ( (39,800 – 15,000) / 80,700) * 100 = 30.73%

Payback period:

Years

0

1

2

3

4

5

Investment

80,700

-

-

-

-

-

Cash Flow

-

24,800

24,800



24,800



24,800



24,800



Cumulative

-80,700

-55,900

-31,100

-6,300

18,500

43,300



























































 

NPV (5%):  = = 26,671.02 SAR in 5 years 

Break-even-point: 80700 / 24800 = 3.2 years 



Funding Strategy:

Ask for funding of 80,700 to install the required hardware/software and implement the proposed design and pitch a 30.73% ROI in 5 years and show in the payback period that the project will start gaining income after 3 years. With the improvements in water efficiency, crop yield, and manual labor reductions, the profit increases by 39,800 per year which accelerates the payback period.

Comparison between the three options



Option 1

Option 2

Option 3

Cost

0

32,300

80,700

Operational cost



5,000

15,000

Break-even-point

-

5.15 years

3.2 years

NPV (5%) in 5 years

-

-$2171.5 

26,671.02

ROI

-

19.4%

30.73%







Major Risks





The following table summarizes the major risks regarding the implementation and long-term operation of the Smart Agricultural Monitoring and Control System. Each risk is evaluated by its category, likelihood, impact, and mitigation strategy. These considerations are essential for real-world deployment and help in planning responses should any of these risks occur.

No.

Description

Category

Likelihood / Impact

Mitigation Strategy

1

Sensor or actuator failure in the field

Technical

Medium / High

Implement regular maintenance schedules and provide backup/replacement hardware

2

AI model misclassification of plant health

Technical

Medium / High

Retrain model periodically with updated datasets; include human-in-the-loop review

3

Network or cloud communication outages

Infrastructure

Medium / High

Enable local fallback control in microcontrollers; use multiple communication paths

4

User resistance to adopting and using the system

Operational

Medium / Medium

Provide training programs and intuitive UI; demonstrate ROI through pilot projects

5

Data privacy and security breaches in cloud-hosted data

Security

Low / High

Encrypt all data at rest and in transit; apply strict access control policies

6

Hardware incompatibility with existing farm infrastructure

Technical

Medium / Medium

Perform site assessments prior to deployment; offer modular system design



































