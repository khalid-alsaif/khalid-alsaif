# 2- PMP

King Fahad University of Petroleum and Minerales 

COE384 

Project Management Plan



Project Name:

Smart Agricultural Monitoring and Control System

Group Number:

Team 6

Date:

08/03/2025

Release:

Draft/Final

Student 1 Name:

Khalid Alsaif

Signature:



Student 1 ID: 

[student ID removed]





Author 2 Name:

Saud Alsaleem

Signature:



Student 2 ID: 

[student ID removed]





Author 3 Name:

Mojtaba Alsaad

Signature:



Student 3 ID: 

[student ID removed]





Author 4 Name:

Kureym Alzarea

Signature:



Student 4 ID: 

[student ID removed]





Author 5 Name:

Ahmed Alghamdi

Signature:



Student 5 ID: 

[student ID removed]





Document Number:

T242-COE384-PMP-002

Revision History

Revision Date

Previous Revision Date

Summary of Changes

Changes Marked

09/03/2025







11/03/2025

09/03/2025

Made some changes to improve the executive summary, scope, and constrains and assumptions















Approvals

This document requires the following approvals.  A signed copy should be placed in the project files.

Name

Signature

Title

Date of Issue

Version

Dr. Akram Fadhl N. Ahmed





Professor at Computer Engineering in KFUPM

09/03/2025

001

Dr. Akram Fadhl N. Ahmed







Professor at Computer Engineering in KFUPM



11/03/2025

002















Distribution

This document has been distributed to:

Name

Title

Date of Issue

Version

Abdulaziz Ashy 





COE Student at KFUPM 





09/03/2025

001

Moaz Abdelaziz 





COE Student at KFUPM 





09/03/2025

001



Abdullah Al-Arafat 





COE Student at KFUPM 





09/03/2025

001

Ziad Algamdi 





COE Student at KFUPM 





09/03/2025

001

Thamer Alotaibi 





COE Student at KFUPM 





09/03/2025

001

Dr. Akram Fadhl N. Ahmed

Professor at Computer Engineering in KFUPM

11/03/2025

002









































Contents

1.Executive Summary of Project Charter4

2.Assumptions/Constraints4

3.Scope of project4

4.Work Breakdown Structure5

5.Change Control Management5

6.Schedule/Time Management5

6.1.Milestones5

6.2.Project Schedule6

7.WBS9

























Executive Summary of Project Charter

This system is intended to support sustainable farming by conserving water, minimizing labor use, and improving crop production. Because of the lack of water, wrong ways of applying water in farming, and lack of frequent monitoring, agriculture in Saudi Arabia has several problems that result in consumption of water that is not necessary and reduced production. The Smart Agricultural Monitoring and Control System is an IoT-based solution that uses sensor technology, AI-based plant health assessment, and cloud computing to improve water use and automate farm operations. The real-time environmental data will be gathered by soil moisture, temperature, and pressure sensors while an AI-driven image recognition model that has been trained using deep learning will analyze images from farm cameras to identify unhealthy plants. The data is collected and analyzed and then stored in the cloud where the farmers can get real-time information on the dashboard and control the irrigation system remotely. Automated actuators control the water application according to the AI prediction; therefore, water is only applied when it is needed. Moreover, the predictive analytics function of AI can help to reveal the early signs of plant diseases to avoid losses. This is because the solution does not require a master microcontroller to control the farm monitoring as cloud computing is used for expansion and control. This initiative is designed to improve food security and optimize the management of agricultural resources by using real-time monitoring, automation, and AI-based decision making. 



Assumptions/Constraints

Assumptions:

Climate conditions are suitable for deploying IoT sensors with temperatures and humidity levels not exceeding hardware capabilities

The farm can support renewable energy sources such as solar panels

Technical support is available to guide farmers on using the system

The farming area is divided into relatively small squares (10m x 10m)

The irrigation control system will be compatible with existing farm equipment

Constraints:

The project must align with the Saudi Arabian government requirements and regulations for agricultural and food production

The IoT sensors and AI components must function with minimum maintenance requirements

Budget constraints may limit access to high-end hardware if the farm is large

Network availability may be limited in remote farming areas



Scope of project

The goal of the project is to implement a smart agricultural monitoring and control system that will solve the issues of water wastage and crop management, where dry conditions and limited water sources pose a significant challenge in Saudi Arabia. Traditional methods of irrigation such as flood irrigation, often result in poor crop yield and inefficient water usage since farmers don’t have real-time monitoring equipment to monitor crops’ condition. The proposed system aims to solve these issues by integrating IoT sensors to monitor crop conditions and utilize AI models to analyze collected data from sensors, providing suggestions to optimize irrigation and to detect crop diseases early on. The data will be collected from the sensors installed in the microcontrollers and securely transmitted to the cloud to get processed and stored, allowing farmers to easily access data via the web dashboard and access the maintenance logs if needed. The system will also control actuators based on the data stored in the cloud to optimize irrigation and to shut down the water supply in case of actuators not functioning properly. Additionally, the system will optimize power consumption by identifying devices that highly consume power using an AI algorithm to identify devices with high power consumption and implementing smart power-saving strategies to reduce unnecessary power consumption such as deactivating idle devices, also renewable energy sources such as solar panels will also be included. Lastly, the system will encrypt the collected data and provide access only to those who have authorization to prevent data manipulation. In conclusion, by automating irrigation and providing real-time data monitoring, the system will enhance water usage and improve crop yields by using integrated IoT sensors and utilizing AI alongside the cloud platform to enable farmers to remotely monitor their crops.



Work Breakdown Structure

See WBS in page 11

 

Change Control Management

Identifying the Need for Change – If a potential issue arises, such as scheduled maintenance from the cloud service provider, a change request will be raised.

Impact Assessment & Decision Making – The team will assess the impact of the change on the project timeline and performance, adjusting schedules or finding alternative solutions if necessary.

Approval & Documentation – If a change is needed, the team will document the modification and update the project plan accordingly.

Implementation & Communication – The change will be applied while ensuring all team members are informed to maintain workflow continuity. 

If it was identified during the implementation of the cloud platform that there was a scheduled server maintenance from the cloud service provider, the project team will initiate changes in the timeline deployment to adjust and reschedule certain tasks in order to ensure minimal delay to the overall project and store data in a backup server to avoid failure in processing the collected data until the scheduled maintenance is completed. These changes will enhance the workflow, minimize the disruption for the project, and ensure work continuity.



Schedule/Time Management

Milestones

The table below lists the milestones for this project, along with their estimated completion timeframe.

Milestones 

Estimated Completion Timeframe

MIL1: Hardware & Sensors Installed 

March 21, 2025 

MIL2: AI Model Deployed 

April 15, 2025

MIL3: Microcontroller & Network Fully Operational

April 22, 2025

MIL4: Cloud Deployed

May 1, 2025

MIL5: Dashboard & UI/UX Ready

May 8, 2025

Project Schedule



















































WBS

































