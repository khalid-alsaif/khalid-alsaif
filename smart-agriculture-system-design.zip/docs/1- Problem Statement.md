# 1- Problem Statement

King Fahad University of Petroleum and Minerales 

COE384 

Problem Statement Document



Project Name:

Smart Agricultural Monitoring and Control System

Section:

1

Group Number:

6

Date:

23/1/2025

Release:

Draft/Final

Student 1 Name:

KHALID ALSAIF

Signature:



Student 1 ID: 

[student ID removed]





Author 2 Name:

Saud Alsaleem

Signature:



Student 2 ID: 

[student ID removed]





Author 3 Name:

Mojtaba Alsaad

Signature:



Student 3 ID: 

[student ID removed]





Author 4 Name:

Kureym Alzarea

Signature:



Student 4 ID: 

[student ID removed]





Author 5 Name:

Ahmed Alghamdi

Signature:



Student 5 ID: 

[student ID removed]





Document Number:

T242-COE384-PS-003

Revision History

Revision Date

Previous Revision Date

Summary of Changes

Changes Marked

31/01/2025

-

Added more clarification in paragraph 1 and added references at the end of paragraph 2.



03/02/2025

31/01/2025

Improved paragraphs 1 and 2 and updated the references.















Approvals

This document requires the following approvals.  A signed copy should be placed in the project files.

Name

Signature

Title

Date of Issue

Version

Dr. Akram Fadhl N. Ahmed





Professor at Computer Engineering in KFUPM

1/23/2025

002

Dr. Akram Fadhl N. Ahmed





Professor at Computer Engineering in KFUPM

3/2/2025

003

















Distribution

This document has been distributed to:

Name

Title

Date of Issue

Version

Abdulaziz Ashy



COE Student at KFUPM

23/01/2025

001

Moaz Abdelaziz



COE Student at KFUPM



23/01/2025



001



Abdullah Al-Arafat



COE Student at KFUPM



23/01/2025



001



Ziad Algamdi



COE Student at KFUPM



23/01/2025



001



Thamer Alotaibi



COE Student at KFUPM



23/01/2025



001



Dr. Akram Fadhl N. Ahmed

Professor at Computer Engineering in KFUPM

31/01/2025

002

Dr. Akram Fadhl N. Ahmed

Professor at Computer Engineering in KFUPM

03/02/2025

003









Motivation and Problem Statement 

Paragraph1:

Because of the dry climate and limited water supplies, agriculture in Saudi Arabia faces many challenges. Traditional methods of irrigating crops waste a lot of water and do not always promote good plant growth. From Table 1, about 80 percent of Saudi Arabia’s demand for water is consumed by agricultural practices. With that added to the limited water resources issue, this poses a significant challenge to the main objective of Saudi Arabia’s 2030 vision, which is efficiency at all levels. Furthermore, farmers generally lack tools that would monitor soil or weather conditions in real-time, preventing them from making the most effective decision of when to water their crops. This problem could be eliminated by utilizing smart concepts such as IoTs, Artificial Intelligence, and Cloud Computing. These tools will also help save water, and track crops’ condition. By using IoT sensors, data on soil, weather, and crops can be collected in real-time, and then analyzed by AI to optimize crop health and water usage. Finally, collected data gets stored and processed in the cloud. By utilizing these technologies, farmers can make informed decisions based on the collected data and improve crops’ quality by controlling the environment they grow in, reduce water usage, and increase productivity.



 









Paragraph2:

Saudi Arabia’s limited water supplies make it challenging to meet soaring demand driven by population growth, industrial expansion, and agricultural requirements. According to Landhuis (2024), an agricultural counselor for the Gulf Cooperation Council, the country ranks among the driest globally yet exhibits one of the highest rates of water consumption worldwide. This stark disparity underscores the urgent need to adopt intelligent systems that optimize water usage, particularly in agriculture, which accounts for the largest share of the nation’s water consumption. Furthermore, Al Humaid (2024) notes that low irrigation efficiency—estimated at approximately 50%, compared to the best global practices of 85%—combined with the excessive extraction of non-renewable groundwater, poses a significant threat to agricultural productivity and food security. This highlights the urgent need for substantial improvements in Saudi Arabia’s irrigation systems, a challenge this project aims to address. Ultimately, without modernizing agricultural practices, achieving long-term sustainability in water management and food production will remain an insurmountable obstacle.



















References:

1 - Landhuis, S. (2024, 5 November). Agricultural Counselor for the Gulf Cooperation Council. https://www.agroberichtenbuitenland.nl/actueel/nieuws/2024/11/05/as12-saudi-arabia-water-crisis-how-do-they-handle-sustainable-agriculture-and-water-management 



2 - Al-Humaid, M. (2024, October 3). From scarcity to sustainability: A leap toward efficient irrigation in Saudi Arabia. Food and Agriculture Organization of the United Nations. https://www.fao.org/neareast/news/stories/details/from-scarcity-to-sustainability--a-leap-toward-efficient-irrigation-in-saudi-arabia/en 

3- Alodah, A. (2023). Towards sustainable water resources management considering climate change in the case of Saudi Arabia. Advances in Sustainable Management of the Water Environment, 15(20). https://doi.org/10.3390/su152014674 



 



































List of Stakeholders 



The planned stakeholders are:

Name

Title

Roles in the project

Comments

Saleh Alsaleem

Farmer

Collecting information, regarding challengings and issues to Agriculture

+966 50 323 4077

Saeed Abdullah Al Ali

Agricultural Specialist

Collecting requirements related to Agricultural practices

+966 58 200 0907















Use of generative AI

We used Chat GPT to improve the grammar and structure of the paragraphs, and to gather more information about agricultural practices and the problems that they are facing alongside the possible solutions to solve those problems. Additionally, some concepts were not very clear at the beginning of our work, so we asked Chat GPT to clarify some concepts regarding agriculture

Examples of some of the prompts that we used:















