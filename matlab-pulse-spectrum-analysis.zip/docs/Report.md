# Report



KING FAHD UNIVERSITY OF PETROLEUM & MINERALS

COMPUTER ENGINEERING DEPARTMENT

COE-241 – Data and Computer Communication Matlab Programming Assignment #1 - Due Date March 28th, 2024 – In Class.

Name: KHALID ALI ALSAIFName: KHALID ALI ALSAIFID: [student ID removed]ID: [student ID removed]SECTION: 02SECTION: 02Date: 28/3/2024Date: 28/3/2024

Name: KHALID ALI ALSAIF

Name: KHALID ALI ALSAIF

ID: [student ID removed]

ID: [student ID removed]

SECTION: 02

SECTION: 02

Date: 28/3/2024

Date: 28/3/2024





Problem [100 points] It is required to write a Matlab code that analyzes the Fourier Transform for the three pulses considered in class: (1) rectangular pulse, (2) triangular pulse, and (3) cosine pulse. The code does the following:

The user selects the pulse: 1, 2, or 3. If the user selects other than 1, 2, or 3, it informs user of wrong selection and does not proceed.

Asks the user to specify the variables: pulse amplitude 𝐴 in volts and pulse width 𝑟 in seconds.

The code plots the pulse as a function of time on the interval 𝑡 ∈ (−𝑟, 𝑟). The plots for the respective pulses must be done using the following Matlab functions: rectpuls() for the rectangular pulse, tripuls() for the triangular pulse, and cos() for the cosine pulse. No other method of defining 𝑝(𝑡) is accepted.

The code plots the energy spectral density function for the selected pulse versus frequency on an interval that includes the main lobe plus two side lobes either side of the 0 Hz.

The code computes the total energy and practical bandwidth for the selected pulse.

Use the code to explore the relation between the pulse width  and the practical bandwidth of the pulse. – State your observations and comments.

Sample runs are shown below for some specific parameters. For the plots the students are to use proper axes labels and the specified ranges above.



The developed Matlab code should be very organized and well documented. Use variable names identical or very close to the mathematical variable used in this problem statement. The documentation should clearly specify the sections of the code that correspond to each part of this programming assignment. Students will work on this assignment as teams of two students. The Matlab code must use the following functions: rectpuls, tripuls(), and cos() to generate the required pulses. It must also use the switch statement to process the user selection.

Students are encouraged to cooperatively discuss the problem and the Matlab know-how; however, each team must write and submit his own code. The submitted codes and reports will be inspected for similarities. The instructor will schedule 15-minutes interviews with selected teams and discuss the submitted code/results.



Generate the sample runs/outputs shown below and import them into an organized Microsoft word file along with comments on the obtained results. The word file should also contain a listing of the Matlab code at the end. Zip the word file together with the Matlab code and submit the zipped file to the Blackboard. The name of the zipfileshouldcontainthefollowingpattern: ID1_LastName1_FirstName1_ID2_LastName2_FirstName2_PA1.zip. ID, LastName, and FirstName are the information for the respective student.



In addition, teams must ALSO submit a hardcopy of the Microsoft word file (i.e. the report) that includes a properly formatted listing of the used Matlab code. The grader is going to mark the hardcopy and use the blackboard to obtain a softcopy of the code.

To import figures into your word document, go to the Matlab figure Edit menu and select “copy figure”. Paste

(special) the figure into the word file as “Picture (Enhanced Metafile)”. Please do not paste as any other format.



Sample Runs:

>> porograming_assaignment_1

Enter (1) Rectangular, (2) Triangular, (3) Cosine: 5

Unknown pulse

>>

Sample run # 1



Comments on Results:

{provide comments/analysis on results}

The program will show the message (Unknown pulse) when the user enters a number that is not one of the choices (1,2,3), but when the user doesn't enter a number, the program will generate an error. 





>> porograming_assaignment_1

Enter (1) Rectangular, (2) Triangular, (3) Cosine: 1

Amplitude A (volts) = 1

Taw parameter (sec) = 0.2

Number of time samples per Taw = 40

Number of freq samples per Hz =50

rectangular pulse

Practical BW from:    -5.000 Hz to    5.000 Hz

Total energy:   0.20000000 Joules

>>









Sample run # 2





Comments on Results:

{provide comments/analysis on results}



The code segment will start by taking the input needed from the user which are [amplitude(A), taw(the width of the pulse),( Number of time samples per Taw),( Number of frequency samples per Taw)] 

Then I defined the time and frequency axes as follows:

The time axis will be from -taw to taw as required. 

The frequency axis will be -3/taw to 3/taw (the third zero of P(f) where the zeros of P(f) of rectangular pulse are +-n/taw where n=1,2,3…).

Then I defined p(t) and P(f) and ESDF as follows:

P(t)= A*rectpuls(t/taw).

P(f) = A*taw*sin(pi*taw*f)./(pi*taw*f).

ESDF = P(f).*conj(p(f)).





Then I plotted p(t) and ESDF.



Then I calculated the total energy which can be obtained by integrating the square of the pulse in the time domain from -infinity to infinity which will be equal to A^2*taw.

Then I calculated the practical bandwidth which is from -1/taw to 1/taw (where 1/taw is the first zero of P(f))

Finaly, the pulse width  and the practical bandwidth of the pulse are inversely proportional (when  increase the BW will decrease and vice versa ).





>> porograming_assaignment_1

Enter (1) Rectangular, (2) Triangular, (3) Cosine: 2

Amplitude A (volts) = 1

Taw parameter (sec) = 0.2

Number of time samples per Taw = 50

Number of freq samples per Hz =100

Triangular pulse

Practical BW from:    -5.000 Hz to    5.000 Hz

Total energy:   0.13333333 Joules

>>









Sample run # 3





Comments on Results:

{provide comments/analysis on results}



The code segment will start by taking the input needed from the user which are [amplitude(A), taw(the width of the pulse),( Number of time samples per Taw),( Number of frequency samples per Taw)] 

Then I defined the time and frequency axes as follows:

The time axis will be from -taw to taw as required. 

The frequency axis will be -3/taw to 3/taw (the third zero of P(f) where the zeros of P(f) of triangular pulse are +-n/taw where n=1,2,3…).

Then I defined p(t) and P(f) and ESDF as follows:

P(t)= A*tripuls(t,2*taw).

P(f) = A*taw*(sin(pi*taw*f)./(pi*taw*f)).^2. 

ESDF = P(f).*conj(p(f)).



Then I plotted p(t) and ESDF.



Then I calculated the total energy which can be obtained by integrating the square of the pulse in the time domain from -infinity to infinity which will be equal to (2*A^2*taw)/3.





Then I calculated the practical bandwidth which is from -1/taw to 1/taw (where 1/taw is the first zero of P(f))

Finaly, the pulse width  and the practical bandwidth of the pulse are inversely proportional (when  increase the BW will decrease and vice versa ).





>> porograming_assaignment_1

Enter (1) Rectangular, (2) Triangular, (3) Cosine: 3

Amplitude A (volts) = 1

Taw parameter (sec) = 0.2

Number of time samples per Taw = 50

Number of freq samples per Hz =100

Cosine pulse

Practical BW from:    -7.500 Hz to    7.500 Hz

Total energy:   0.10000000 Joules

>>









Sample run # 3





Comments on Results:

{provide comments/analysis on results}



The code segment will start by taking the input needed from the user which are [amplitude(A), taw(the width of the pulse),( Number of time samples per Taw),( Number of frequency samples per Taw)] 

Then I defined the time and frequency axes as follows:

The time axis will be from -taw to taw as required. 

The frequency axis will be -7/(2*taw) to 7/(2*taw) (the third zero of P(f) where the zeros of P(f) of cosine pulse are +-n/(2*taw) where n=3,5,7,9…(odd numbers except 1)).

Then I defined p(t) and P(f) and ESDF as follows:

P(t)= max(A*cos(pi*t/taw),0).

P(f) = (2*A*taw)/pi*cos(pi*taw*f)./(1-(2*taw*f).^2). 

ESDF = P(f).*conj(p(f)).



Then I plotted p(t) and ESDF.



Then I calculated the total energy which can be obtained by integrating the square of the pulse in the time domain from -infinity to infinity which will be equal to A^2*taw/2.









Then I calculated the practical bandwidth which is from -3/(2*taw) to 3/(2*taw) (where 3/(2*taw) is the first zero of P(f))

Finaly, the pulse width  and the practical bandwidth of the pulse are inversely proportional (when  increase the BW will decrease and vice versa ).



Listing of Documented Code:

{List your documented code here}



clear all; 

LineWidth = 2; FontSize = 14;



%promt the user to enter a desired pulse

result = input('Enter (1) Rectangular, (2) Triangular, (3) Cosine: ');



switch result %swich statment to give answer based of the user choise

    case 1 %when the user enter 1(rectangular pulse)

        A=input('Amplitude A (volts) = '); %promt the user to enter Amplitude

        taw= input('Taw parameter (sec) = '); %promt the user to enter taw(the width of the pulse)

        numOfTimeSamples=input('Number of time samples per Taw = ');%promt the user to enter the Number of time samples per Taw

        numOfFreqSamples= input('Number of freq samples per Hz =');%promt the user to enter the Number of freq samples per Taw

        fprintf('rectangular pulse\n');



        %difine time and frequency axes

        t = -taw : taw/numOfTimeSamples :taw;

        f = -3/taw:taw/numOfFreqSamples:3/taw;



        %define fmin & fmax (the first zeros of P(f) function) to find

        %practical BW

        fmin= -1/taw;

        fmax= 1/taw;

        

        %define p(t) and P(f) and ESDF

        p_t = A*rectpuls(t/taw);

        P_f = A*taw*sin(pi*taw*f)./(pi*taw*f); % The corresponding F.T P(f)

        ESDF_f = P_f.*conj(P_f); % The ESDF 

        

        %plot p(t) and ESDF

        figure(1); clf; set(gca, 'FontSize', FontSize);

        plot(t, p_t, 'LineWidth', LineWidth);

        title('rectangular pulse - time domain');

        xlabel('time (sec)'); ylabel('p(t) volts'); grid on;

        figure(2); clf; set(gca, 'FontSize', FontSize);

        h = plot(f, ESDF_f, 'LineWidth', LineWidth);

        title('rectangular pulse - frequency domain');

        xlabel('frequency (Hz)'); ylabel('ESDF Joules/Hz'); grid on;

        

        %clculate the total energy and print the practical BW and total energy

        enrgy= A^2*taw;

        fprintf('Practical BW from:    %.3f Hz to    %.3f Hz\n',fmin,fmax);

        fprintf('Total energy:   %.8f Joules\n',enrgy);

        

    case 2 %when the user enter 2(Triangular pulse)

        A=input('Amplitude A (volts) = ');%promt the user to enter Amplitude

        taw= input('Taw parameter (sec) = ');%promt the user to enter taw(the width of the pulse)

        numOfTimeSamples=input('Number of time samples per Taw = ');%promt the user to enter the Number of time samples per Taw





        numOfFreqSamples= input('Number of freq samples per Hz =');%promt the user to enter the Number of freq samples per Taw

        fprintf('Triangular pulse\n');

        

        %define fmin & fmax (the first zeros of P(f) function) to find

        %practical BW

        fmin= -1/taw;

        fmax= 1/taw;

        

        %difine time and frequency axes

        t = -taw : taw/numOfTimeSamples :taw;

        f = -3/taw:taw/numOfFreqSamples:3/taw;

        

        %define p(t) and P(f) and ESDF

        p_t = A*tripuls(t,2*taw);

        P_f = A*taw*(sin(pi*taw*f)./(pi*taw*f)).^2; % The corresponding F.T P(f)

        ESDF_f = P_f.*conj(P_f); % The ESDF 

        

        %plot p(t) and ESDF

        figure(1); clf; set(gca, 'FontSize', FontSize);

        plot(t, p_t, 'LineWidth', LineWidth);

        title('Triangular pulse - time domain');

        xlabel('time (sec)'); ylabel('p(t) volts'); grid on;

        figure(2); clf; set(gca, 'FontSize', FontSize);

        h = plot(f, ESDF_f, 'LineWidth', LineWidth);

        title('Triangular pulse - frequency domain');

        xlabel('frequency (Hz)'); ylabel('ESDF Joules/Hz'); grid on;



        %clculate the total energy and print the practical BW and total energy

        enrgy= (2*A^2*taw)/3;

        fprintf('Practical BW from:    %.3f Hz to    %.3f Hz\n',fmin,fmax);

        fprintf('Total energy:   %.8f Joules\n',enrgy);



    case 3 %when the user enter 3(Cosine pulse)

        A=input('Amplitude A (volts) = ');%promt the user to enter Amplitude

        taw= input('Taw parameter (sec) = ');%promt the user to enter taw(the width of the pulse)

        numOfTimeSamples=input('Number of time samples per Taw = ');%promt the user to enter the Number of time samples per Taw

        numOfFreqSamples= input('Number of freq samples per Hz =');%promt the user to enter the Number of freq samples per Taw

        fprintf('Cosine pulse\n');

        

        %define fmin & fmax (the first zeros of P(f) function) to find

        %practical BW

        fmin= -3/(2*taw);

        fmax= 3/(2*taw);

        

        %difine time and frequency axes

        t = -taw : taw/numOfTimeSamples :taw;

        f = -7/(2*taw):taw/numOfFreqSamples:7/(2*taw); 



        %define p(t) and P(f) and ESDF

        p_t = max(A*cos(pi*t/taw),0);

        P_f = (2*A*taw)/pi*cos(pi*taw*f)./(1-(2*taw*f).^2); 

        ESDF_f = P_f.*conj(P_f); 



        %plot p(t) and ESDF

        figure(1); clf; set(gca, 'FontSize', FontSize);

        plot(t, p_t, 'LineWidth', LineWidth);

        title('Cosine pulse - time domain');

        xlabel('time (sec)'); ylabel('p(t) volts'); grid on;

        figure(2); clf; set(gca, 'FontSize', FontSize);

        h = plot(f, ESDF_f, 'LineWidth', LineWidth);

        title('Cosine pulse - frequency domain');

        xlabel('frequency (Hz)'); ylabel('ESDF Joules/Hz'); grid on;



        %clculate the total energy and print the practical BW and total energy

        enrgy= A^2*taw/2;

        fprintf('Practical BW from:    %.3f Hz to    %.3f Hz\n',fmin,fmax);

        fprintf('Total energy:   %.8f Joules\n',enrgy);



        

    otherwise %when the user doesn't enter a valid  choice

        disp('Unknown pulse')

end

