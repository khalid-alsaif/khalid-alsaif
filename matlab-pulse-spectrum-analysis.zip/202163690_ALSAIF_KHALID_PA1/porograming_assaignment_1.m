clear all; 
LineWidth = 2; FontSize = 14;

%promt the user to enter a desired pulse
result = input('Enter (1) Rectangular, (2) Triangular, (3) Cosine: ');

switch result %swich statment to give answer based of the user choise
    case 1 %when the user enter 1(rectangular pulse)
        A=input('Amplitude A (volts) = '); %promt the user to enter Amplitude
        taw= input('Taw parameter (sec) = '); %promt the user to enter taw(the width of the pulse)
        numOfTimeSamples=input('Number of time samples per Taw = ');%promt the user to enter the Number of time samples per Taw
        numOfFreqSamples= input('Number of freq samples per Hz =');%promt the user to enter the Number of freq samples per Taw
        fprintf('rectangular pulse\n');

        %difine time and frequency axes
        t = -taw : taw/numOfTimeSamples :taw;
        f = -3/taw:taw/numOfFreqSamples:3/taw;

        %define fmin & fmax (the first zeros of P(f) function) to find
        %practical BW
        fmin= -1/taw;
        fmax= 1/taw;
        
        %define p(t) and P(f) and ESDF
        p_t = A*rectpuls(t/taw);
        P_f = A*taw*sin(pi*taw*f)./(pi*taw*f); % The corresponding F.T P(f)
        ESDF_f = P_f.*conj(P_f); % The ESDF 
        
        %plot p(t) and ESDF
        figure(1); clf; set(gca, 'FontSize', FontSize);
        plot(t, p_t, 'LineWidth', LineWidth);
        title('rectangular pulse - time domain');
        xlabel('time (sec)'); ylabel('p(t) volts'); grid on;
        figure(2); clf; set(gca, 'FontSize', FontSize);
        h = plot(f, ESDF_f, 'LineWidth', LineWidth);
        title('rectangular pulse - frequency domain');
        xlabel('frequency (Hz)'); ylabel('ESDF Joules/Hz'); grid on;
        
        %clculate the total energy and print the practical BW and total energy
        enrgy= A^2*taw;
        fprintf('Practical BW from:    %.3f Hz to    %.3f Hz\n',fmin,fmax);
        fprintf('Total energy:   %.8f Joules\n',enrgy);
        
    case 2 %when the user enter 2(Triangular pulse)
        A=input('Amplitude A (volts) = ');%promt the user to enter Amplitude
        taw= input('Taw parameter (sec) = ');%promt the user to enter taw(the width of the pulse)
        numOfTimeSamples=input('Number of time samples per Taw = ');%promt the user to enter the Number of time samples per Taw
        numOfFreqSamples= input('Number of freq samples per Hz =');%promt the user to enter the Number of freq samples per Taw
        fprintf('Triangular pulse\n');
        
        %define fmin & fmax (the first zeros of P(f) function) to find
        %practical BW
        fmin= -1/taw;
        fmax= 1/taw;
        
        %difine time and frequency axes
        t = -taw : taw/numOfTimeSamples :taw;
        f = -3/taw:taw/numOfFreqSamples:3/taw;
        
        %define p(t) and P(f) and ESDF
        p_t = A*tripuls(t,2*taw);
        P_f = A*taw*(sin(pi*taw*f)./(pi*taw*f)).^2; % The corresponding F.T P(f)
        ESDF_f = P_f.*conj(P_f); % The ESDF 
        
        %plot p(t) and ESDF
        figure(1); clf; set(gca, 'FontSize', FontSize);
        plot(t, p_t, 'LineWidth', LineWidth);
        title('Triangular pulse - time domain');
        xlabel('time (sec)'); ylabel('p(t) volts'); grid on;
        figure(2); clf; set(gca, 'FontSize', FontSize);
        h = plot(f, ESDF_f, 'LineWidth', LineWidth);
        title('Triangular pulse - frequency domain');
        xlabel('frequency (Hz)'); ylabel('ESDF Joules/Hz'); grid on;

        %clculate the total energy and print the practical BW and total energy
        enrgy= (2*A^2*taw)/3;
        fprintf('Practical BW from:    %.3f Hz to    %.3f Hz\n',fmin,fmax);
        fprintf('Total energy:   %.8f Joules\n',enrgy);

    case 3 %when the user enter 3(Cosine pulse)
        A=input('Amplitude A (volts) = ');%promt the user to enter Amplitude
        taw= input('Taw parameter (sec) = ');%promt the user to enter taw(the width of the pulse)
        numOfTimeSamples=input('Number of time samples per Taw = ');%promt the user to enter the Number of time samples per Taw
        numOfFreqSamples= input('Number of freq samples per Hz =');%promt the user to enter the Number of freq samples per Taw
        fprintf('Cosine pulse\n');
        
        %define fmin & fmax (the first zeros of P(f) function) to find
        %practical BW
        fmin= -3/(2*taw);
        fmax= 3/(2*taw);
        
        %difine time and frequency axes
        t = -taw : taw/numOfTimeSamples :taw;
        f = -7/(2*taw):taw/numOfFreqSamples:7/(2*taw); 

        %define p(t) and P(f) and ESDF
        p_t = max(A*cos(pi*t/taw),0);
        P_f = (2*A*taw)/pi*cos(pi*taw*f)./(1-(2*taw*f).^2); 
        ESDF_f = P_f.*conj(P_f); 

        %plot p(t) and ESDF
        figure(1); clf; set(gca, 'FontSize', FontSize);
        plot(t, p_t, 'LineWidth', LineWidth);
        title('Cosine pulse - time domain');
        xlabel('time (sec)'); ylabel('p(t) volts'); grid on;
        figure(2); clf; set(gca, 'FontSize', FontSize);
        h = plot(f, ESDF_f, 'LineWidth', LineWidth);
        title('Cosine pulse - frequency domain');
        xlabel('frequency (Hz)'); ylabel('ESDF Joules/Hz'); grid on;

        %clculate the total energy and print the practical BW and total energy
        enrgy= A^2*taw/2;
        fprintf('Practical BW from:    %.3f Hz to    %.3f Hz\n',fmin,fmax);
        fprintf('Total energy:   %.8f Joules\n',enrgy);

        
    otherwise %when the user doesn't enter a valid  choice
        disp('Unknown pulse')
end

