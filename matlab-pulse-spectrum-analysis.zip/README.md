# MATLAB Pulse Spectrum Analysis

MATLAB analysis of rectangular, triangular, and cosine pulses, including time-domain plots, energy spectral density, total energy, and practical bandwidth.

## Technologies

MATLAB / signal processing

## Explore the project

Run porograming_assaignment_1.m in MATLAB and enter the requested pulse parameters. rectpuls and tripuls require the appropriate MATLAB toolbox.

## Files

- `[student ID removed]_ALSAIF_KHALID_PA1/porograming_assaignment_1.m`
- `docs/Report.md`

## Project context

Academic project: COE241. These are archival portfolio files; builds and hardware behavior have not been revalidated. Team projects retain contributor names where available; individual ownership of all components is not implied.

Reports are provided as extracted text. Original images, formatting, signatures, student IDs, duplicate archives, and large demo files are omitted.
