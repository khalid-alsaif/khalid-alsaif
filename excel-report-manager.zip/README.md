# Spreadsheet Report Manager

A Python menu-based application for finding, adding, modifying, and removing reports stored in an Excel workbook.

## Technologies

Python / Jupyter / openpyxl

## Explore the project

Install openpyxl and open the notebook. Use a workbook with fictional data matching the expected columns. The supplied spreadsheets and notebook outputs are omitted from the public copy because they may contain patient information.

## Files

- `Project.ipynb`
- `docs/Report.md`

## Project context

Academic project: ICS104. These are archival portfolio files; builds and hardware behavior have not been revalidated. Team projects retain contributor names where available; individual ownership of all components is not implied.

Reports are provided as extracted text. Original images, formatting, signatures, student IDs, duplicate archives, and large demo files are omitted.
