# Report

Section:  81Team members: Nayef AL-Qahtani([student ID removed])Khalid ALsaif([student ID removed])Section:  81Team members: Nayef AL-Qahtani([student ID removed])Khalid ALsaif([student ID removed])Project Report

Section:  81

Team members: 

Nayef AL-Qahtani([student ID removed])

Khalid ALsaif([student ID removed])



Section:  81

Team members: 

Nayef AL-Qahtani([student ID removed])

Khalid ALsaif([student ID removed])





The description of how did we solve the project :

We started by understanding the project and then we had a general imagination how the code will look like. Then we decided to divide the project to several functions. The first function ( main() ) and second function ( userMenu() ) and then one function for each choice in the main menu. we started whit ( main() ) function where the code will start from, then we wrote ( userMenu() ) that will show the menu to the user. After that, we started with writing the functions (we will take about soon) that execute the menu's contents. Finally, we tested the program and added the comments and writing the report. 



The Description of the test cases that have been tested:

To make sure that we are walking in the right direction we tested the program after every task we do. Also, we put in mind all scenarios. In addition, we tested the program many times after finishing the program.

A few cases of the test that we did and the problem that we came up against:

one of the problems that we got was that the when we where adding a new report we couldn't modify it after because the date that we added was considered a string so then we figured that the function to solve that problem is strptime which converts a string to a data time object

after we figured how to add a report and modify it we discovered another problem which was that the alignment of the report was wrong the solution turned out to be the function Alignment() which we got from openpyxl.styles  then we did a loop on the row of the added report which centered everything.

When we tried to save the workbook when the user chose number 6,7 from the menu we find that the workbook is not be saved if the save statement outside the functions that have been used, so we passed (ws) that represent worksheet to each function.  



The Contribution of each team member:

Most of the time we worked next to each other.

The Description of the different functions with their tasks:

1. main() : the function is main function from which the code will start, and it will start asking the user to enter the file location and will print the number of the report existing in the file. Also, it will contact with other functions to execute what the user want.

2.  userMenu() :  it will show the menu and ask the user to enter the number of the choice that he want and it will return the choice.

3. findPatient(userInput,numReports): this function will ask the user to enter the PID of the patient and it will print his information .

4. addReport(userInput,numReports): this function will ask the user to enter the information that the user want to add, then it will check if the report exist or not, if it is not exist it will print a message, otherwise, it will add the new report.

5. modify(userInput,numReports): this function will ask the user to enter the information that the user want to modify the grade of the patient, then it will check if the report exist or not, if it is not exist it will print a message, otherwise, it will ask the user to enter the new grade, and it will add the new grade instead of the old one.

7. : this function save the file but in different file. So, it will aske the user to enter the new path and then check if this path is correct or not, if it is not correct, it will print a message, and return to the main menu. Otherwise, it will save the file and print a massage.







Screenshots of the running code. And the test cases that have been tested:

Screenshot of the code:





Screenshots of the test cases:

1- 



2-  



3- 

