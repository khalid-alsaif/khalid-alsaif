# Enterprise Network Architecture Design

An academic report on enterprise network architecture and hierarchical core, distribution, and access layers.

## Technologies

Computer networks / enterprise architecture

## Explore the project

This is a report-based project. The supplied folder has a report and presentation but no network simulator or configuration files. Read docs for the report text; original presentation media is omitted.

## Files

- `docs/Project Report - COE444.md`

## Project context

Academic project: COE444. These are archival portfolio files; builds and hardware behavior have not been revalidated. Team projects retain contributor names where available; individual ownership of all components is not implied.

Reports are provided as extracted text. Original images, formatting, signatures, student IDs, duplicate archives, and large demo files are omitted.
